package de.lowfin.tv;

import android.content.*;
import android.content.pm.ProviderInfo;
import android.database.*;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import androidx.tvprovider.media.tv.TvContractCompat;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import org.robolectric.shadows.ShadowContentResolver;
import java.io.*;
import java.util.*;
import java.util.function.BooleanSupplier;
import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=30)
public class HomeChannelsTest {
    private LowfinApp app; private FakeTvProvider provider; private Account account;
    @Before public void setup() {
        app=(LowfinApp)RuntimeEnvironment.getApplication();
        provider=new FakeTvProvider(); ProviderInfo info=new ProviderInfo(); info.authority=TvContractCompat.AUTHORITY; info.name=FakeTvProvider.class.getName(); info.packageName="com.android.providers.tv";
        provider.attachInfo(app,info); ShadowContentResolver.registerProviderInternal(info.authority,provider); shadowOf(app.getPackageManager()).addOrUpdateProvider(info);
        account=new Account("https://unit.example","user","secret-token","Demo User","device"); app.setAccount(account);
        JSONObject current=episode("resume",600000000L),next=episode("next",0);
        app.library.put(current); app.library.put(next);
        app.library.put(Json.obj("Id","movie","Type","Movie","Name","Ein Film")); app.library.put(Json.obj("Id","show","Type","Series","Name","Eine Serie"));
        app.library.state("home-0",Json.arr(current).toString()); app.library.state("home-1",Json.arr(next).toString());
    }
    @After public void cleanup() { if(app.images!=null) app.images.close(); app.io.shutdownNow(); app.reports.shutdownNow(); }
    private JSONObject episode(String id,long ticks) { return Json.obj("Id",id,"Type","Episode","Name","Eine Folge","SeriesName","Eine Serie","SeriesId","show","ParentIndexNumber",40,"IndexNumber",6,"RunTimeTicks",27000000000L,"UserData",Json.obj("PlaybackPositionTicks",ticks)); }
    @Test public void createsFourChannelsAndAddsContinueAndNextToWatchNext() throws Exception {
        app.channels.publish(); await(()->provider.count("watch_next_program")==2);
        assertEquals(4,provider.count("channel")); assertEquals(4,provider.count("preview_program"));
        ContentValues continuing=provider.byProviderId("watch_next_program",account.scope()+":resume");
        assertEquals(Integer.valueOf(TvContractCompat.WatchNextPrograms.WATCH_NEXT_TYPE_CONTINUE),continuing.getAsInteger("watch_next_type"));
        assertEquals(Integer.valueOf(60000),continuing.getAsInteger("last_playback_position_millis"));
        assertFalse(continuing.getAsString("intent_uri").contains("secret-token"));
    }
    @Test public void updatesProgressWithoutDuplicatingOrRecreatingChannels() throws Exception {
        app.channels.publish(); await(()->provider.count("watch_next_program")==2);
        Set<Long> ids=provider.ids("channel"); long programId=provider.byProviderId("watch_next_program",account.scope()+":resume").getAsLong("_id");
        app.library.put(episode("resume",1200000000L)); Thread.sleep(30); app.channels.publish();
        await(()->provider.byProviderId("watch_next_program",account.scope()+":resume").getAsInteger("last_playback_position_millis")==120000);
        assertEquals(ids,provider.ids("channel")); assertEquals(programId,(long)provider.byProviderId("watch_next_program",account.scope()+":resume").getAsLong("_id"));
        assertEquals(2,provider.count("watch_next_program"));
    }
    @Test public void removingHomeCardsNeverTouchesAnotherAppsPrograms() throws Exception {
        app.channels.publish(); await(()->provider.count("watch_next_program")==2);
        provider.foreign("watch_next_program"); app.channels.cancelAndClear();
        await(()->provider.count("watch_next_program")==1&&provider.count("preview_program")==0);
        assertEquals("another.app",provider.all("watch_next_program").get(0).getAsString("package_name"));
        assertEquals(4,provider.count("channel"));
    }
    @Test public void dismissedWatchNextItemsStayDismissedUntilExplicitPlayback() throws Exception {
        app.channels.publish(); await(()->provider.count("watch_next_program")==2);
        provider.browse("watch_next_program",account.scope()+":resume",false); Thread.sleep(30); app.channels.publish(); await(()->provider.count("watch_next_program")==1);
        Thread.sleep(30); app.channels.publish(); Thread.sleep(100); assertNull(provider.byProviderId("watch_next_program",account.scope()+":resume"));
        app.channels.engaged(account,"resume"); app.channels.publish(); await(()->provider.count("watch_next_program")==2);
    }
    @Test public void artworkProviderOnlyReadsCurrentAccountsCoverFiles() throws Exception {
        ArtProvider art=new ArtProvider(); ProviderInfo info=new ProviderInfo(); info.authority="de.lowfin.tv.art"; art.attachInfo(app,info);
        String name="a".repeat(64)+".jpg"; File directory=new File(app.getFilesDir(),"covers-"+account.scope()); directory.mkdirs();
        try(OutputStream out=new FileOutputStream(new File(directory,name))) { out.write(new byte[]{1,2,3}); }
        Uri uri=Uri.parse("content://de.lowfin.tv.art/"+account.scope()+"/"+name);
        try(ParcelFileDescriptor descriptor=art.openFile(uri,"r")) { assertNotNull(descriptor); }
        for(Uri bad:Arrays.asList(Uri.parse("content://de.lowfin.tv.art/other/"+name),Uri.parse("content://de.lowfin.tv.art/"+account.scope()+"/account.xml"))) {
            try { art.openFile(bad,"r"); fail("Invalid artwork path must fail"); } catch(FileNotFoundException expected) {}
        }
        try { art.openFile(uri,"w"); fail("Must not allow writes"); } catch(FileNotFoundException expected) {}
        app.setAccount(null); try { art.openFile(uri,"r"); fail("Logged out account must not expose artwork"); } catch(FileNotFoundException expected) {}
    }
    @Test public void launcherLinksCarryItemAndScopeWithoutAuthSecrets() {
        Intent link=HomeChannels.link(app,account,"episode","resume");
        assertEquals("lowfin",link.getData().getScheme()); assertEquals("episode",link.getData().getLastPathSegment());
        assertEquals(account.scope(),link.getStringExtra(HomeChannels.EXTRA_SCOPE)); assertEquals("resume",link.getStringExtra(HomeChannels.EXTRA_MODE));
        assertFalse(link.toUri(Intent.URI_INTENT_SCHEME).contains("secret-token")); assertFalse(link.toUri(Intent.URI_INTENT_SCHEME).contains("unit.example"));
    }
    @Test public void longDurationsAndNegativeProgressDoNotOverflowTvProviderIntegers() { assertEquals(Integer.MAX_VALUE,HomeChannels.ms(Long.MAX_VALUE)); assertEquals(0,HomeChannels.ms(-1)); }
    private void await(BooleanSupplier condition) throws Exception { long end=System.currentTimeMillis()+8000; while(System.currentTimeMillis()<end) { if(condition.getAsBoolean()) return; Thread.sleep(20); } fail("TV provider update timed out"); }

    public static final class FakeTvProvider extends ContentProvider {
        private final Map<String,Map<Long,ContentValues>> tables=new HashMap<>(); private long next=1;
        @Override public boolean onCreate() { return true; }
        private String table(Uri uri) { return uri.getPathSegments().get(0); }
        private Map<Long,ContentValues> rows(String table) { return tables.computeIfAbsent(table,x->new LinkedHashMap<>()); }
        synchronized int count(String table) { return rows(table).size(); }
        synchronized Set<Long> ids(String table) { return new HashSet<>(rows(table).keySet()); }
        synchronized List<ContentValues> all(String table) { return new ArrayList<>(rows(table).values()); }
        synchronized ContentValues byProviderId(String table,String id) { for(ContentValues v:rows(table).values()) if(id.equals(v.getAsString("internal_provider_id"))) return new ContentValues(v); return null; }
        synchronized void foreign(String table) { ContentValues v=new ContentValues(); v.put("_id",next++); v.put("package_name","another.app"); v.put("internal_provider_id","foreign"); v.put("browsable",1); rows(table).put(v.getAsLong("_id"),v); }
        synchronized void browse(String table,String id,boolean enabled) { for(ContentValues v:rows(table).values()) if(id.equals(v.getAsString("internal_provider_id"))) v.put("browsable",enabled?1:0); }
        @Override public synchronized Uri insert(Uri uri,ContentValues values) { ContentValues v=new ContentValues(values); v.put("_id",next++); v.put("package_name","de.lowfin.tv"); v.put("browsable",1); rows(table(uri)).put(v.getAsLong("_id"),v); return ContentUris.withAppendedId(uri,v.getAsLong("_id")); }
        @Override public synchronized int update(Uri uri,ContentValues values,String where,String[] args) { ContentValues v=rows(table(uri)).get(ContentUris.parseId(uri)); if(v==null) return 0; v.putAll(values); return 1; }
        @Override public synchronized int delete(Uri uri,String where,String[] args) { return rows(table(uri)).remove(ContentUris.parseId(uri))==null?0:1; }
        @Override public synchronized Cursor query(Uri uri,String[] projection,String where,String[] args,String sort) {
            MatrixCursor out=new MatrixCursor(projection); String channel=uri.getQueryParameter("channel"); Long id=uri.getPathSegments().size()>1?ContentUris.parseId(uri):null;
            for(ContentValues v:rows(table(uri)).values()) {
                if(id!=null&&!id.equals(v.getAsLong("_id"))) continue;
                if(channel!=null&&!channel.equals(v.getAsString("channel_id"))) continue;
                Object[] row=new Object[projection.length]; for(int i=0;i<projection.length;i++) row[i]=v.get(projection[i]); out.addRow(row);
            } return out;
        }
        @Override public String getType(Uri uri) { return "image/png"; }
        @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException { return ParcelFileDescriptor.open(new File(getContext().getCacheDir(),"channel-logo.png"),ParcelFileDescriptor.MODE_READ_WRITE|ParcelFileDescriptor.MODE_CREATE|ParcelFileDescriptor.MODE_TRUNCATE); }
    }
}
