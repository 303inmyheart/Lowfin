package de.lowfin.tv;

import org.json.JSONObject;

/** Choose real artwork before deciding its frame; never put a poster in a thumbnail frame. */
final class Artwork {
    static String type(JSONObject item,boolean wide) {
        JSONObject tags=Json.object(item,"ImageTags");
        if(wide&&!Json.str(tags,"Thumb").isEmpty()) return "Thumb";
        if(wide&&!"Episode".equals(item.optString("Type"))&&Json.array(item,"BackdropImageTags").length()>0) return "Backdrop";
        return "Primary";
    }
    static JSONObject backdrop(JSONObject item) {
        org.json.JSONArray tags=Json.array(item,"BackdropImageTags"); String id=item.optString("Id");
        if(tags.length()==0) { tags=Json.array(item,"ParentBackdropImageTags"); id=Json.str(item,"ParentBackdropItemId"); }
        return tags.length()==0||id.isEmpty()?null:Json.obj("Id",id,"Type","Movie","BackdropImageTags",tags);
    }
    static boolean crop(JSONObject item,boolean wide) { return ratio(item,wide)>1.2&&!item.optString("Type").equals("TvChannel"); }
    static double ratio(JSONObject item,boolean wide) {
        String kind=item.optString("Type");
        if(kind.equals("Movie")||kind.equals("Series")||kind.equals("Season")||kind.equals("BoxSet")) return 2.0/3;
        if(kind.equals("Episode")) return 16.0/9;
        if(!type(item,wide).equals("Primary")) return 16.0/9;
        boolean primary=!Json.str(Json.object(item,"ImageTags"),"Primary").isEmpty();
        if(!primary&&!Json.str(item,"SeriesPrimaryImageTag").isEmpty()) return 2.0/3;
        if(kind.equals("Movie")||kind.equals("Series")||kind.equals("Season")||kind.equals("BoxSet")) return 2.0/3;
        if(kind.equals("Episode")||kind.equals("Video")) return 16.0/9;
        double ratio=item.optDouble("PrimaryImageAspectRatio",kind.equals("TvChannel")?1:16.0/9);
        return Double.isFinite(ratio)&&ratio>=.25&&ratio<=4?ratio:16.0/9;
    }
}
