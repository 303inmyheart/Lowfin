package de.lowfin.tv;

import android.content.Context;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.*;
import org.json.JSONObject;
import java.util.*;
import java.util.function.*;

/** Virtualized shelves, with bounded D-pad navigation and persistent horizontal positions. */
final class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.Shelf> {
    final List<String> labels=new ArrayList<>(Arrays.asList("Weiterschauen","Als Nächstes","Neu in deiner Bibliothek"));
    final List<List<JSONObject>> rows=new ArrayList<>();
    private final Images images;
    private final BiConsumer<JSONObject,Integer> play;
    private final IntConsumer more;
    private final BiConsumer<JSONObject,Integer> focused;
    private final IntConsumer move;
    private RecyclerView owner;
    private int pendingRow=-1,focusedGenre=-1;
    private final RecyclerView.RecycledViewPool pool=new RecyclerView.RecycledViewPool();
    private final Map<String,android.os.Parcelable> positions=new HashMap<>();
    HomeAdapter(Images images,List<String> genres,BiConsumer<JSONObject,Integer> play,IntConsumer more,BiConsumer<JSONObject,Integer> focused,IntConsumer move) {
        this.images=images; this.play=play; this.more=more; this.focused=focused; this.move=move; labels.addAll(genres);
        for(int i=0;i<labels.size();i++) rows.add(new ArrayList<>()); setHasStableIds(true);
    }
    @Override public void onAttachedToRecyclerView(RecyclerView recycler) { owner=recycler; }
    void setFocusedGenre(int row) {
        focusedGenre=row>=3?row:-1;
        if(owner!=null) for(int i=0;i<owner.getChildCount();i++) { View child=owner.getChildAt(i); int index=owner.getChildAdapterPosition(child); child.setVisibility(focusedGenre<0||index==focusedGenre?View.VISIBLE:View.INVISIBLE); }
    }
    void requestRow(int row) {
        if(owner==null||row<0||row>=rows.size()) return; pendingRow=row;
        ((LinearLayoutManager)owner.getLayoutManager()).scrollToPositionWithOffset(row,0);
        owner.post(()-> { Shelf shelf=(Shelf)owner.findViewHolderForAdapterPosition(row); if(shelf!=null) focusPending(shelf); });
    }
    private void focusPending(Shelf shelf) {
        if(pendingRow<0||shelf.getBindingAdapterPosition()!=pendingRow) return;
        View card=shelf.list.getChildAt(0);
        if(card!=null) { if(card.requestFocus()) pendingRow=-1; } else if(rows.get(pendingRow).isEmpty()) { pendingRow=-1; shelf.all.requestFocus(); }
    }
    void update(int index,List<JSONObject> data) { rows.set(index,data); notifyItemChanged(index); }
    @Override public int getItemCount() { return rows.size(); }
    @Override public long getItemId(int position) { return position; }
    @Override public Shelf onCreateViewHolder(ViewGroup parent,int type) {
        Context c=parent.getContext(); LinearLayout box=Ui.column(c); box.setPadding(0,Ui.dp(c,8),0,Ui.dp(c,4));
        LinearLayout head=Ui.row(c); TextView label=Ui.title(c,"",18); head.addView(label,new LinearLayout.LayoutParams(0,-2,1));
        Button all=Ui.button(c,"Alle anzeigen →",()->{}); head.addView(all); box.addView(head); Ui.space(box,3);
        TextView empty=Ui.text(c,"Wird geladen …",14,Ui.MUTED); empty.setPadding(Ui.dp(c,5),Ui.dp(c,12),0,Ui.dp(c,12)); box.addView(empty);
        RecyclerView list=new ShelfList(c); list.setLayoutManager(new LinearLayoutManager(c,RecyclerView.HORIZONTAL,false));
        list.setRecycledViewPool(pool); list.setItemAnimator(null); list.setHasFixedSize(true); list.setItemViewCacheSize(2);
        list.setNestedScrollingEnabled(false); list.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        box.addView(list,new LinearLayout.LayoutParams(-1,Ui.dp(c,194)));
        box.setLayoutParams(new RecyclerView.LayoutParams(-1,-2)); Shelf shelf=new Shelf(box,label,all,empty,list);
        ((ShelfList)list).afterLayout=()->focusPending(shelf); return shelf;
    }
    @Override public void onBindViewHolder(Shelf shelf,int index) {
        if(shelf.key!=null) positions.put(shelf.key,shelf.list.getLayoutManager().onSaveInstanceState());
        shelf.itemView.setVisibility(focusedGenre<0||index==focusedGenre?View.VISIBLE:View.INVISIBLE);
        shelf.key=labels.get(index); shelf.label.setText(labels.get(index)); shelf.all.setOnClickListener(v->{ int position=shelf.getBindingAdapterPosition(); if(position!=RecyclerView.NO_POSITION) more.accept(position); });
        List<JSONObject> data=rows.get(index); shelf.empty.setVisibility(data.isEmpty()?View.VISIBLE:View.GONE); shelf.empty.setText("Hier erscheinen deine "+(index==0?"angefangenen Filme und Folgen":index==1?"nächsten Folgen":index>=3?labels.get(index)+"-Filme":"neuen Filme und Serien"));
        shelf.list.setVisibility(data.isEmpty()?View.GONE:View.VISIBLE);
        shelf.all.setOnKeyListener((view,key,event)-> { int direction=key==KeyEvent.KEYCODE_DPAD_UP?-1:key==KeyEvent.KEYCODE_DPAD_DOWN?1:0; int row=shelf.getBindingAdapterPosition();
            if(direction!=0&&row!=RecyclerView.NO_POSITION&&row+direction>=0&&row+direction<rows.size()) { if(event.getAction()==KeyEvent.ACTION_DOWN) move.accept(row+direction); return true; } return false;
        });
        shelf.all.setOnFocusChangeListener((v,hasFocus)-> { v.setBackground(Ui.background(hasFocus?0xff383838:Ui.PANEL,hasFocus?Color.WHITE:0)); if(hasFocus) focused.accept(data.isEmpty()?null:data.get(0),shelf.getBindingAdapterPosition()); });
        Cards adapter=(Cards)shelf.list.getAdapter();
        if(adapter==null) {
            adapter=new Cards(images,new ArrayList<>(),item->{ int position=shelf.getBindingAdapterPosition(); if(position!=RecyclerView.NO_POSITION) play.accept(item,position); },item->{ int position=shelf.getBindingAdapterPosition(); if(position!=RecyclerView.NO_POSITION) focused.accept(item,position); },direction->{ int position=shelf.getBindingAdapterPosition(); if(position!=RecyclerView.NO_POSITION&&position+direction>=0&&position+direction<rows.size()) { move.accept(position+direction); return true; } return false; }); shelf.list.setAdapter(adapter);
        }
        adapter.update(data);
        int height=180; for(JSONObject item:data) { double ratio=Artwork.ratio(item,true); height=Math.max(height,(int)Math.ceil((ratio<1?106:216)/ratio)+60); }
        ViewGroup.LayoutParams dimensions=shelf.list.getLayoutParams(); dimensions.height=Ui.dp(shelf.list.getContext(),height); shelf.list.setLayoutParams(dimensions);
        if(positions.containsKey(shelf.key)) shelf.list.getLayoutManager().onRestoreInstanceState(positions.get(shelf.key));
        shelf.list.post(()->focusPending(shelf));
    }
    @Override public void onViewRecycled(Shelf shelf) { if(shelf.key!=null) positions.put(shelf.key,shelf.list.getLayoutManager().onSaveInstanceState()); }
    static final class Shelf extends RecyclerView.ViewHolder {
        final TextView label,empty; final Button all; final RecyclerView list; String key;
        Shelf(View v,TextView label,Button all,TextView empty,RecyclerView list) { super(v); this.label=label; this.all=all; this.empty=empty; this.list=list; }
    }
    /** Android's default focus search can move right into the next vertical row. */
    static final class ShelfList extends RecyclerView {
        Runnable afterLayout;
        ShelfList(Context context) { super(context); }
        @Override protected void onLayout(boolean changed,int left,int top,int right,int bottom) { super.onLayout(changed,left,top,right,bottom); if(afterLayout!=null) post(afterLayout); }
        @Override public View focusSearch(View focused,int direction) {
            View card=findContainingItemView(focused); int position=card==null?NO_POSITION:getChildAdapterPosition(card);
            if(position!=NO_POSITION&&(direction==View.FOCUS_RIGHT||direction==View.FOCUS_LEFT)) {
                int target=position+(direction==View.FOCUS_RIGHT?1:-1);
                if(target>=getAdapter().getItemCount()) return focused;
                if(target>=0) {
                    View next=getLayoutManager().findViewByPosition(target); if(next!=null) return next;
                    scrollToPosition(target); post(()-> { View loaded=getLayoutManager().findViewByPosition(target); if(loaded!=null) loaded.requestFocus(); }); return focused;
                }
            }
            return super.focusSearch(focused,direction);
        }
    }
    private static final class Cards extends RecyclerView.Adapter<Card> {
        private final Images images; private List<JSONObject> data; private final Consumer<JSONObject> open,focused; private final IntPredicate move;
        Cards(Images images,List<JSONObject> data,Consumer<JSONObject> open,Consumer<JSONObject> focused,IntPredicate move) { this.images=images; this.data=data; this.open=open; this.focused=focused; this.move=move; setHasStableIds(true); }
        @Override public long getItemId(int position) { return stableId(data.get(position)); }
        private long stableId(JSONObject j) { long hash=0xcbf29ce484222325L; for(char c:j.optString("Id").toCharArray()) { hash^=c; hash*=0x100000001b3L; } return hash; }
        void update(List<JSONObject> next) {
            List<JSONObject> before=data;
            DiffUtil.DiffResult diff=DiffUtil.calculateDiff(new DiffUtil.Callback() {
                @Override public int getOldListSize() { return before.size(); }
                @Override public int getNewListSize() { return next.size(); }
                @Override public boolean areItemsTheSame(int a,int b) { return before.get(a).optString("Id").equals(next.get(b).optString("Id")); }
                @Override public boolean areContentsTheSame(int a,int b) { return before.get(a).toString().equals(next.get(b).toString()); }
            }); data=next; diff.dispatchUpdatesTo(this);
        }
        @Override public int getItemViewType(int position) { return Artwork.ratio(data.get(position),true)<1?0:1; }
        @Override public int getItemCount() { return data.size(); }
        @Override public Card onCreateViewHolder(ViewGroup parent,int type) {
            Context c=parent.getContext(); LinearLayout box=Ui.column(c); Ui.cardFocus(box); box.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS); box.setPadding(Ui.dp(c,5),Ui.dp(c,5),Ui.dp(c,5),Ui.dp(c,5));
            RecyclerView.LayoutParams lp=new RecyclerView.LayoutParams(Ui.dp(c,type==0?116:226),-2); lp.setMargins(Ui.dp(c,4),Ui.dp(c,4),Ui.dp(c,8),Ui.dp(c,4)); box.setLayoutParams(lp);
            ArtworkView cover=new ArtworkView(c); box.addView(cover,new LinearLayout.LayoutParams(-1,-2));
            ProgressBar progress=new ProgressBar(c,null,android.R.attr.progressBarStyleHorizontal); progress.setMax(1000); progress.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.WHITE)); progress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff444444));
            box.addView(progress,new LinearLayout.LayoutParams(-1,Ui.dp(c,3))); Ui.space(box,4);
            TextView title=Ui.text(c,"",13,Color.WHITE); title.setMaxLines(1); title.setEllipsize(android.text.TextUtils.TruncateAt.END); box.addView(title);
            TextView episode=Ui.text(c,"",11,Ui.MUTED); episode.setMaxLines(1); episode.setEllipsize(android.text.TextUtils.TruncateAt.END); box.addView(episode);
            return new Card(box,cover,progress,title,episode);
        }
        @Override public void onBindViewHolder(Card h,int index) {
            JSONObject j=data.get(index); h.cover.ratio(Artwork.ratio(j,true)); h.cover.crop(Artwork.crop(j,true)); boolean episode="Episode".equals(j.optString("Type"));
            h.title.setText(episode?j.optString("SeriesName",j.optString("Name")):j.optString("Name"));
            h.episode.setText(episode?Json.label(j):j.optString("ProductionYear","")+"  ·  "+j.optLong("RunTimeTicks")/600000000+" min");
            long pos=Json.position(j),duration=j.optLong("RunTimeTicks")/10000;
            h.progress.setProgress(duration>0?(int)Math.min(1000,pos*1000/duration):0); h.progress.setVisibility(pos>0?View.VISIBLE:View.INVISIBLE);
            // Install the styling once per holder; binding must not recursively wrap listeners.
            h.itemView.setOnFocusChangeListener((view,hasFocus)-> { h.focusStyle.onFocusChange(view,hasFocus); if(hasFocus) focused.accept(j); });
            h.itemView.setOnKeyListener((view,key,event)-> {
                if(key==KeyEvent.KEYCODE_DPAD_UP||key==KeyEvent.KEYCODE_DPAD_DOWN) {
                    if(event.getAction()==KeyEvent.ACTION_DOWN) return move.test(key==KeyEvent.KEYCODE_DPAD_UP?-1:1);
                    return true;
                } return false;
            });
            images.show(h.cover,j,"Episode".equals(j.optString("Type"))); h.itemView.setContentDescription((episode?j.optString("SeriesName")+" · ":"")+Json.label(j)); h.itemView.setOnClickListener(v->open.accept(j));
        }
        @Override public void onViewRecycled(Card h) { h.cover.setTag(null); h.cover.setImageDrawable(null); h.itemView.animate().cancel(); }
    }
    private static final class Card extends RecyclerView.ViewHolder {
        final ArtworkView cover; final ProgressBar progress; final TextView title,episode; final View.OnFocusChangeListener focusStyle;
        Card(View v,ArtworkView cover,ProgressBar progress,TextView title,TextView episode) { super(v); this.cover=cover; this.progress=progress; this.title=title; this.episode=episode; this.focusStyle=v.getOnFocusChangeListener(); }
    }
}
