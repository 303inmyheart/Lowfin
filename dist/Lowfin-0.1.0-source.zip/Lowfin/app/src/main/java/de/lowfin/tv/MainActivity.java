package de.lowfin.tv;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.*;
import org.json.*;
import java.util.*;

@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
public final class MainActivity extends Activity {
    private LowfinApp app;
    private LinearLayout root,body;
    private TextView status;
    private RecyclerView grid;
    private final Deque<Screen> history=new ArrayDeque<>();
    private Screen screen;
    private int generation;
    private Runnable homeReload;
    private LinearLayout sidebar;
    private final List<JSONObject> views=new ArrayList<>();
    private boolean viewsLoading;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable statusTick=new Runnable() { public void run() {
        if(status!=null) status.setText(app.syncing?app.syncStatus:screen!=null&&screen.kind.equals("settings")?app.syncStatus:app.account==null?"":app.account.name+"  ·  HD");
        handler.postDelayed(this,2000);
    }};
    private static final int PAGE=60;
    private static final class Screen {
        final String kind,title,type,parent; final JSONObject item;
        int page; Parcelable scroll;
        Screen(String kind,String title,String type,String parent,JSONObject item) { this.kind=kind; this.title=title; this.type=type; this.parent=parent; this.item=item; }
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); app=(LowfinApp)getApplication(); Ui.immersive(this);
        if(app.account==null) login(""); else {
            show(new Screen("home","Deine Bibliothek",null,null,null),false); checkSession();
            loadViews();
            String last=app.settings.getString("lastChannel","");
            if(hasHomeLink(getIntent())) handleHomeLink(getIntent());
            else if(savedNone(state)&&app.settings.getBoolean("liveOnLaunch",false)&&!last.isEmpty()) play(Json.obj("Id",last,"Type","TvChannel","Name","Live TV"),0);
        }
    }
    private boolean savedNone(Bundle state) { return state==null; }
    @Override protected void onResume() { super.onResume(); Ui.immersive(this); handler.post(statusTick); if(homeReload!=null&&screen!=null&&screen.kind.equals("home")) homeReload.run(); }
    @Override protected void onPause() { handler.removeCallbacks(statusTick); super.onPause(); }
    @Override protected void onDestroy() { generation++; handler.removeCallbacksAndMessages(null); super.onDestroy(); }
    private void checkSession() {
        final Api api=app.api;
        app.io.execute(()-> {
            try { api.get("/Users/Me");
                runOnUiThread(()-> { if(app.api==api&&!isFinishing()&&!app.syncing) {
                    String last=app.library.state("lastSync"); long time=0; try { time=Long.parseLong(last); } catch(Exception ignored) {}
                    if(System.currentTimeMillis()-time>24*60*60*1000L) startCache();
                }});
            } catch(Api.Failure e) { if(e.status==401||e.status==403) runOnUiThread(()-> { if(app.api==api) { app.logout(); history.clear(); login("Bitte erneut anmelden"); } }); }
            catch(Exception e) { runOnUiThread(()-> { if(app.api==api) toast("Server nicht erreichbar. Gespeicherte Bibliothek bleibt verfügbar."); }); }
        });
    }
    private void login(String error) {
        generation++; screen=null; grid=null;
        LinearLayout outer=Ui.column(this); outer.setGravity(Gravity.CENTER); outer.setBackgroundColor(Ui.BG);
        LinearLayout form=Ui.column(this); outer.addView(form,new LinearLayout.LayoutParams(Ui.dp(this,470),-2));
        form.addView(Ui.title(this,"LOWFIN",36)); Ui.space(form,8);
        form.addView(Ui.text(this,"Deine Medien. Direkt auf deinem TV.",17,Ui.MUTED)); Ui.space(form,24);
        EditText server=Ui.input(this,"Server · https://jellyfin.example",false);
        server.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);
        server.setText(app.settings.getString("lastServer","")); form.addView(server); Ui.space(form,10);
        EditText user=Ui.input(this,"Benutzername",false); form.addView(user); Ui.space(form,10);
        EditText password=Ui.input(this,"Passwort",true); form.addView(password); Ui.space(form,16);
        TextView hint=Ui.text(this,error,14,Ui.MUTED);
        Button signIn=Ui.button(this,"Anmelden",()-> {
            String address=server.getText().toString().trim().replaceAll("/+$","");
            okhttp3.HttpUrl u=okhttp3.HttpUrl.parse(address);
            if(u==null||u.host().isEmpty()||!u.username().isEmpty()||!u.password().isEmpty()||u.query()!=null||u.fragment()!=null) { hint.setText("Bitte eine vollständige Serveradresse ohne Zugangsdaten oder URL-Parameter angeben."); return; }
            String username=user.getText().toString().trim(),secret=password.getText().toString();
            if(username.isEmpty()) { hint.setText("Benutzername fehlt"); return; }
            hint.setText("Verbindung wird hergestellt …");
            final int g=generation;
            app.io.execute(()-> {
                try {
                    Api api=new Api(new Account(address,"","","",Account.device(this)));
                    JSONObject response=api.post("/Users/AuthenticateByName",Json.obj("Username",username,"Pw",secret));
                    JSONObject account=Json.object(response,"User");
                    Account a=new Account(address,account.getString("Id"),response.getString("AccessToken"),account.optString("Name",username),Account.device(this));
                    runOnUiThread(()-> { if(g!=generation||isFinishing()) return;
                        try { a.save(this); app.setAccount(a); app.settings.edit().putString("lastServer",address).apply(); password.setText("");
                            views.clear(); viewsLoading=false; show(new Screen("home","Deine Bibliothek",null,null,null),false); loadViews(); startCache(); if(hasHomeLink(getIntent())) handleHomeLink(getIntent());
                        } catch(Exception e) { hint.setText("Sitzung konnte nicht sicher gespeichert werden."); }
                    });
                } catch(Exception e) { runOnUiThread(()-> { if(g==generation) hint.setText(e instanceof Api.Failure?e.getMessage():"Verbindung fehlgeschlagen. Adresse und Netzwerk prüfen."); }); }
            });
        });
        form.addView(signIn); Ui.space(form,12); form.addView(hint);
        status=null; setContentView(outer); server.requestFocus();
    }
    private void shell(String title) {
        root=Ui.row(this); root.setGravity(Gravity.TOP); root.setBackgroundColor(Ui.BG); root.setPadding(Ui.dp(this,20),Ui.dp(this,18),Ui.dp(this,24),Ui.dp(this,18));
        LinearLayout left=Ui.column(this); left.setPadding(Ui.dp(this,10),Ui.dp(this,8),Ui.dp(this,10),Ui.dp(this,12)); left.setBackground(Ui.background(0xff151515,0));
        left.addView(Ui.title(this,"LOWFIN",24)); Ui.space(left,22);
        ScrollView menu=new ScrollView(this); menu.setVerticalScrollBarEnabled(false); sidebar=Ui.column(this); menu.addView(sidebar); left.addView(menu,new LinearLayout.LayoutParams(-1,0,1));
        Ui.space(left,12); status=Ui.text(this,"",12,Ui.MUTED); status.setMaxLines(3); left.addView(status); root.addView(left,new LinearLayout.LayoutParams(Ui.dp(this,182),-1));
        LinearLayout content=Ui.column(this); content.setPadding(Ui.dp(this,22),Ui.dp(this,4),0,0); root.addView(content,new LinearLayout.LayoutParams(0,-1,1));
        content.addView(Ui.title(this,title,24)); Ui.space(content,12); body=Ui.column(this); content.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        buildSidebar(); grid=null; setContentView(root);
    }
    private void sideButton(String label,Runnable action) {
        Button button=Ui.button(this,label,action); button.setGravity(Gravity.START|Gravity.CENTER_VERTICAL); button.setMaxLines(2); button.setEllipsize(android.text.TextUtils.TruncateAt.END);
        sidebar.addView(button,new LinearLayout.LayoutParams(-1,Ui.dp(this,46))); Ui.space(sidebar,7);
    }
    private void buildSidebar() {
        sidebar.removeAllViews(); sideButton("Start",()->show(new Screen("home","Deine Bibliothek",null,null,null),false)); sideButton("Suche",this::search);
        Ui.space(sidebar,12); sidebar.addView(Ui.text(this,"BIBLIOTHEKEN",11,Ui.MUTED)); Ui.space(sidebar,10);
        if(views.isEmpty()) {
            sideButton("Filme",()->show(new Screen("browse","Filme","Movie",null,null),false)); sideButton("Serien",()->show(new Screen("browse","Serien","Series",null,null),false));
        } else for(JSONObject library:views) {
            if("livetv".equals(library.optString("CollectionType"))) continue;
            sideButton(library.optString("Name"),()->show(new Screen("browse",library.optString("Name"),viewTypes(library),library.optString("Id"),library),false));
        }
        Ui.space(sidebar,12); sideButton("Live TV",()->show(new Screen("live","Live TV",null,null,null),false));
        sideButton("Favoriten",()->special("Favoriten","favorites")); sideButton("Einstellungen",()->show(new Screen("settings","Einstellungen",null,null,null),false));
    }
    static String viewTypes(JSONObject library) { switch(library.optString("CollectionType")) { case "movies":return "Movie"; case "tvshows":return "Series"; case "homevideos":return "Video"; case "boxsets":return "BoxSet"; default:return "Movie,Series,Video,BoxSet"; } }
    private void loadViews() {
        if(viewsLoading||app.api==null) return; viewsLoading=true; final Api api=app.api; final Library db=app.library;
        app.io.execute(()-> {
            try { String saved=db.state("views"); if(!saved.isEmpty()) { List<JSONObject> cached=list(new JSONArray(saved)); runOnUiThread(()-> { if(app.api==api&&sidebar!=null) { views.clear(); views.addAll(cached); buildSidebar(); } }); } } catch(Exception ignored) {}
            try { JSONArray a=Json.array(api.get("/Users/"+api.account.user+"/Views"),"Items"); db.state("views",a.toString()); List<JSONObject> result=list(a);
                runOnUiThread(()-> { if(app.api==api&&sidebar!=null) { views.clear(); views.addAll(result); buildSidebar(); } });
            } catch(Exception ignored) {} finally { runOnUiThread(()-> { if(app.api==api) viewsLoading=false; }); }
        });
    }
    private void show(Screen next,boolean push) {
        if(push&&screen!=null) { if(grid!=null) screen.scroll=grid.getLayoutManager().onSaveInstanceState(); history.push(screen); }
        else if(!push) history.clear();
        screen=next; homeReload=null; generation++; shell(next.title);
        switch(next.kind) {
            case "home": home(); break;
            case "browse": browse(); break;
            case "detail": detail(next.item); break;
            case "seasons": seasons(next.item); break;
            case "episodes": episodes(); break;
            case "live": live(); break;
            case "recordings": recordings(); break;
            case "settings": settings(); break;
            case "search": results(); break;
        }
    }
    private interface Work { List<JSONObject> run() throws Exception; }
    private void async(MediaAdapter adapter,Work work,TextView note) {
        int g=generation;
        app.io.execute(()-> { try { List<JSONObject> data=work.run(); runOnUiThread(()-> { if(g!=generation||isFinishing()||(note==null&&adapter.fresh)) return;
            boolean first=adapter.items.isEmpty(); adapter.set(data); if(note!=null) { adapter.fresh=true; note.setText(data.isEmpty()?"Keine Einträge":""); } if(first) restoreFocus();
        }); } catch(Exception e) { runOnUiThread(()-> { if(g==generation&&note!=null) note.setText(adapter.items.isEmpty()?"Laden fehlgeschlagen: "+e.getMessage():"Gespeicherte Daten · Server aktuell nicht erreichbar"); }); } });
    }
    private static List<JSONObject> list(JSONArray a) { List<JSONObject> out=new ArrayList<>(); for(int i=0;i<a.length();i++) { JSONObject j=a.optJSONObject(i); if(j!=null) out.add(j); } return out; }
    private TextView note(String s) { TextView t=Ui.text(this,s,13,Ui.MUTED); body.addView(t); Ui.space(body,5); return t; }
    private MediaAdapter cards(boolean compact) {
        grid=new RecyclerView(this); int columns=compact?4:Math.max(4,Math.min(6,getResources().getDisplayMetrics().widthPixels/Ui.dp(this,150)));
        grid.setLayoutManager(new GridLayoutManager(this,columns)); grid.setItemAnimator(null); grid.setHasFixedSize(true); grid.setItemViewCacheSize(4);
        MediaAdapter adapter=new MediaAdapter(app.images,compact,this::open); grid.setAdapter(adapter);
        body.addView(grid,new LinearLayout.LayoutParams(-1,0,1)); return adapter;
    }
    private void restoreFocus() {
        if(grid==null) return;
        if(screen.scroll!=null) grid.getLayoutManager().onRestoreInstanceState(screen.scroll);
        grid.post(()-> { if(grid!=null&&grid.getChildCount()>0) grid.getChildAt(0).requestFocus(); });
    }
    private void home() {
        grid=new RecyclerView(this); grid.setLayoutManager(new LinearLayoutManager(this)); grid.setItemAnimator(null); grid.setItemViewCacheSize(1);
        HomeAdapter adapter=new HomeAdapter(app.images,(j,row)-> { if(row<2) play(j,row==0?Json.position(j):0); else open(j); },row->{
            if(row==0) special("Weiterschauen","resume"); else if(row==1) special("Als Nächstes","next"); else show(new Screen("browse","Filme","Movie",null,null),true);
        }); grid.setAdapter(adapter); body.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        final Api api=app.api; final Library db=app.library; final int g=generation; final boolean[] fresh={false,false,false};
        app.io.execute(()-> {
            for(int i=0;i<3;i++) {
                int row=i; List<JSONObject> cached=new ArrayList<>();
                String stored=db.state("home-"+row);
                try { if(!stored.isEmpty()) cached=list(new JSONArray(stored)); } catch(JSONException ignored) {}
                if(cached.isEmpty()&&row==0) cached=db.query("position>0 AND played=0",null,"stamp DESC",18,0);
                if(cached.isEmpty()&&row==2) cached=db.query("type IN ('Movie','Series')",null,"stamp DESC,name",18,0);
                List<JSONObject> data=cached;
                runOnUiThread(()-> { if(g==generation&&!fresh[row]) adapter.update(row,data); });
            }
        });
        final long[] lastRefresh={0};
        homeReload=()-> {
            if(SystemClock.elapsedRealtime()-lastRefresh[0]<1500&&lastRefresh[0]!=0) return; lastRefresh[0]=SystemClock.elapsedRealtime();
            app.io.execute(()-> {
                for(int i=0;i<3;i++) { int row=i; try {
                    JSONObject response;
                    if(row==0) response=api.get("/Users/"+api.account.user+"/Items/Resume","MediaTypes","Video","Limit",18,"Fields","Overview,ParentId");
                    else if(row==1) response=api.get("/Shows/NextUp","UserId",api.account.user,"Limit",18,"Fields","Overview,ParentId","EnableResumable",false);
                    else response=api.get("/Users/"+api.account.user+"/Items","Recursive",true,"IncludeItemTypes","Movie,Series","Limit",18,"SortBy","DateCreated","SortOrder","Descending","Fields","Overview,Genres,DateCreated,ParentId,SortName");
                    JSONArray a=Json.array(response,"Items"); db.put(a,System.currentTimeMillis()); db.state("home-"+row,a.toString()); List<JSONObject> data=list(a);
                    runOnUiThread(()-> { if(g==generation&&!isFinishing()) { fresh[row]=true; adapter.update(row,data); } });
                } catch(Exception ignored) { /* Cached shelves remain usable offline. */ } }
                app.channels.publish();
            });
        }; homeReload.run();
    }
    private void special(String title,String kind) {
        Screen s=new Screen("search",title,kind,null,null); show(s,true);
    }
    private void browse() {
        final Screen s=screen; TextView note=note("Wird geladen …"); MediaAdapter adapter=cards(false); pager();
        final Api api=app.api; final Library db=app.library;
        async(adapter,()->db.browse(s.type,s.parent,null,s.page*PAGE,PAGE),null);
        async(adapter,()-> { JSONArray a=Json.array(api.items(s.page*PAGE,PAGE,s.type,s.parent,null),"Items"); long stamp=System.currentTimeMillis(); db.put(a,stamp); if(s.parent!=null) db.link(s.parent,a,stamp); return list(a); },note);
    }
    private void pager() {
        LinearLayout row=Ui.row(this); Button prev=Ui.button(this,"← Vorherige Seite",()-> { if(screen.page>0) { screen.page--; screen.scroll=null; generation++; shell(screen.title); renderCurrent(); } }); prev.setEnabled(screen.page>0);
        Ui.addButton(row,prev); row.addView(Ui.text(this,"Seite "+(screen.page+1)+"  ·  60 Einträge  ",13,Ui.MUTED));
        Ui.addButton(row,Ui.button(this,"Nächste Seite →",()-> { screen.page++; screen.scroll=null; generation++; shell(screen.title); renderCurrent(); })); body.addView(row);
    }
    private void renderCurrent() { if(screen.kind.equals("episodes")) episodes(); else if(screen.kind.equals("search")) results(); else browse(); }
    private void open(JSONObject item) {
        String type=item.optString("Type");
        if(type.equals("Series")) show(new Screen("seasons",item.optString("Name"),null,item.optString("Id"),item),true);
        else if(type.equals("BoxSet")) show(new Screen("browse",item.optString("Name"),"Movie,Series",item.optString("Id"),item),true);
        else if(type.equals("Season")) show(new Screen("episodes",item.optString("Name"),"Episode",item.optString("Id"),item),true);
        else if(type.equals("TvChannel")) play(item,0);
        else show(new Screen("detail",Json.label(item),null,null,item),true);
    }
    private void seasons(JSONObject series) {
        LinearLayout row=Ui.row(this); Ui.addButton(row,Ui.button(this,"Seriendetails",()->show(new Screen("detail",series.optString("Name"),null,null,series),true)));
        body.addView(row); Ui.space(body,10); note("Staffel auswählen · mit ↑ / ↓ blättern · mit Ziffern zur Staffel springen");
        RecyclerView seasons=new RecyclerView(this); LinearLayoutManager layout=new LinearLayoutManager(this); seasons.setLayoutManager(layout); seasons.setItemAnimator(null);
        List<JSONObject> data=new ArrayList<>(); RecyclerView.Adapter<SeasonRow> adapter=new RecyclerView.Adapter<SeasonRow>() {
            @Override public int getItemCount() { return data.size(); }
            @Override public SeasonRow onCreateViewHolder(ViewGroup parent,int type) {
                Button b=Ui.button(MainActivity.this,"",()->{}); RecyclerView.LayoutParams lp=new RecyclerView.LayoutParams(-1,Ui.dp(MainActivity.this,52)); lp.setMargins(0,0,0,Ui.dp(MainActivity.this,8)); b.setLayoutParams(lp); return new SeasonRow(b);
            }
            @Override public void onBindViewHolder(SeasonRow h,int p) { JSONObject j=data.get(p); ((Button)h.itemView).setText(j.optString("Name")+"  ·  "+j.optInt("RecursiveItemCount",j.optInt("ChildCount"))+" Folgen"); h.itemView.setOnClickListener(v->open(j)); }
        };
        seasons.setAdapter(adapter); body.addView(seasons,new LinearLayout.LayoutParams(-1,0,1)); grid=seasons;
        LinearLayout jump=Ui.row(this); EditText number=Ui.input(this,"Staffel-Nr.",false); number.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); jump.addView(number,new LinearLayout.LayoutParams(Ui.dp(this,160),Ui.dp(this,48)));
        Ui.addButton(jump,Ui.button(this,"Zur Staffel",()-> { int target; try { target=Integer.parseInt(number.getText().toString()); } catch(Exception e) { return; }
            for(int i=0;i<data.size();i++) if(data.get(i).optInt("IndexNumber")==target) { int pos=i; layout.scrollToPositionWithOffset(pos,0); seasons.post(()-> { View v=layout.findViewByPosition(pos); if(v!=null) v.requestFocus(); }); return; }
            toast("Staffel nicht gefunden");
        })); body.addView(jump);
        final int g=generation; final Api api=app.api; final Library db=app.library; final String id=series.optString("Id");
        app.io.execute(()-> {
            List<JSONObject> cached=db.query("type='Season' AND (parent=? OR series=?)",new String[]{id,id},"episode",500,0);
            runOnUiThread(()-> { if(g==generation) { data.clear(); data.addAll(cached); adapter.notifyDataSetChanged(); restoreFocus(); } });
            try { JSONArray a=Json.array(api.get("/Shows/"+id+"/Seasons","UserId",api.account.user,"Fields","Overview,ParentId,RecursiveItemCount"),"Items");
                List<JSONObject> all=list(a); all.sort(Comparator.comparingInt(j->j.optInt("IndexNumber"))); db.put(a,System.currentTimeMillis());
                runOnUiThread(()-> { if(g==generation) { data.clear(); data.addAll(all); adapter.notifyDataSetChanged(); restoreFocus(); } });
            } catch(Exception e) { runOnUiThread(()-> { if(g==generation&&data.isEmpty()) toast("Staffeln konnten nicht geladen werden"); }); }
        });
    }
    private static class SeasonRow extends RecyclerView.ViewHolder { SeasonRow(View v) { super(v); } }
    private void episodes() {
        final Screen s=screen; TextView n=note("Folgen werden geladen …"); MediaAdapter adapter=cards(true); pager();
        final Api api=app.api; final Library db=app.library;
        async(adapter,()->db.browse("Episode",s.parent,null,s.page*PAGE,PAGE),null);
        async(adapter,()-> { String series=s.item.optString("SeriesId",s.item.optString("ParentId"));
            JSONArray a=Json.array(api.get("/Shows/"+series+"/Episodes","UserId",api.account.user,"SeasonId",s.parent,"StartIndex",s.page*PAGE,"Limit",PAGE,"Fields","Overview,MediaSources,MediaStreams,ParentId"),"Items");
            db.put(a,System.currentTimeMillis()); return list(a); },n);
    }
    private void detail(JSONObject original) {
        ImageView image=new ImageView(this); image.setScaleType(ImageView.ScaleType.CENTER_CROP); app.images.show(image,original);
        LinearLayout row=Ui.row(this); row.setGravity(Gravity.TOP); row.addView(image,new LinearLayout.LayoutParams(Ui.dp(this,165),Ui.dp(this,247)));
        LinearLayout content=Ui.column(this); content.setPadding(Ui.dp(this,24),0,0,0); row.addView(content,new LinearLayout.LayoutParams(0,-1,1));
        content.addView(Ui.title(this,original.optString("SeriesName",original.optString("Name")),22)); Ui.space(content,8);
        TextView meta=Ui.text(this,"",14,Ui.MUTED); content.addView(meta); Ui.space(content,12);
        TextView overview=Ui.text(this,original.optString("Overview","Details werden geladen …"),16,Color.WHITE);
        ScrollView scroll=new ScrollView(this); scroll.setFocusable(true); scroll.addView(overview); content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); body.addView(row,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout actions=Ui.row(this); body.addView(actions); Ui.space(body,8);
        final JSONObject[] item={original}; final Runnable[] redraw=new Runnable[1];
        redraw[0]=()-> {
            JSONObject j=item[0]; actions.removeAllViews(); meta.setText(j.optString("ProductionYear","")+"  ·  "+j.optLong("RunTimeTicks")/600000000+" min  ·  "+j.optString("OfficialRating","")); overview.setText(j.optString("Overview","Keine Beschreibung vorhanden"));
            boolean series=j.optString("Type").equals("Series");
            if(series) Ui.addButton(actions,Ui.button(this,"Staffeln",()->show(new Screen("seasons",j.optString("Name"),null,j.optString("Id"),j),true)));
            else {
                if(Json.position(j)>0) Ui.addButton(actions,Ui.button(this,"Fortsetzen · "+Json.position(j)/60000+" min",()->play(j,Json.position(j))));
                Ui.addButton(actions,Ui.button(this,"Abspielen",()->play(j,0)));
            }
            boolean favorite=Json.object(j,"UserData").optBoolean("IsFavorite");
            Ui.addButton(actions,Ui.button(this,favorite?"★ Favorit entfernen":"☆ Favorit",()->mutate(j,"/Users/"+app.account.user+"/FavoriteItems/"+j.optString("Id"),favorite?"DELETE":"POST",()->refreshItem(item,redraw[0]))));
            boolean played=Json.object(j,"UserData").optBoolean("Played");
            Ui.addButton(actions,Ui.button(this,played?"Als ungesehen":"Als gesehen",()->mutate(j,"/Users/"+app.account.user+"/PlayedItems/"+j.optString("Id"),played?"DELETE":"POST",()->refreshItem(item,redraw[0]))));
        };
        redraw[0].run(); refreshItem(item,redraw[0]); actions.getChildAt(0).requestFocus();
    }
    private void refreshItem(JSONObject[] holder,Runnable render) {
        final int g=generation; final Api api=app.api; final Library db=app.library; String id=holder[0].optString("Id");
        app.io.execute(()-> { try { JSONObject j=api.item(id); db.put(j); runOnUiThread(()-> { if(g==generation) { holder[0]=j; render.run(); } }); } catch(Exception ignored) {} });
    }
    private void mutate(JSONObject item,String path,String method,Runnable after) {
        final Api api=app.api; int g=generation;
        app.io.execute(()-> { try { api.call(method,path,null); runOnUiThread(()-> { if(g==generation) after.run(); }); }
            catch(Exception e) { runOnUiThread(()-> { if(g==generation) toast(e.getMessage()); }); } });
    }
    private void play(JSONObject item,long position) {
        if(app.account==null) return;
        startActivity(new Intent(this,PlayerActivity.class).putExtra("item",item.toString()).putExtra("position",position));
    }
    private void live() {
        TextView n=note(""); MediaAdapter adapter=cards(true);
        final Api api=app.api; final Library db=app.library;
        async(adapter,()->db.browse("TvChannel",null,null,0,500),null);
        async(adapter,()-> { JSONArray a=Json.array(api.get("/LiveTv/Channels","UserId",api.account.user,"SortBy","SortName","Fields","ChannelInfo"),"Items"); db.put(a,System.currentTimeMillis()); return list(a); },n);
    }
    private void recordings() {
        TextView n=note("Aufnahmen werden geladen …"); MediaAdapter adapter=cards(true); final Api api=app.api;
        async(adapter,()->list(Json.array(api.get("/LiveTv/Recordings","UserId",api.account.user,"Fields","Overview,MediaSources,MediaStreams"),"Items")),n);
    }
    private void search() {
        EditText input=Ui.input(this,"Titel suchen",false);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Bibliothek durchsuchen").setView(input).setPositiveButton("Suchen",(d,w)->show(new Screen("search",input.getText().toString(),"term",null,null),true)).setNegativeButton("Abbrechen",null).create(); dialog.show(); input.requestFocus();
    }
    private void results() {
        final Screen s=screen; final Api api=app.api; final Library db=app.library;
        TextView n=note("Wird geladen …"); MediaAdapter adapter=cards(false); pager();
        async(adapter,()-> {
            if("resume".equals(s.type)) return db.query("position>0 AND played=0",null,"stamp DESC",PAGE,s.page*PAGE);
            if("favorites".equals(s.type)) return db.query("favorite=1",null,"name",PAGE,s.page*PAGE);
            return db.query("type IN ('Movie','Series','Episode') AND name LIKE ?",new String[]{"%"+s.title+"%"},"name",PAGE,s.page*PAGE);
        },null);
        async(adapter,()-> {
            JSONObject response;
            if(s.type.equals("resume")) response=api.get("/Users/"+api.account.user+"/Items/Resume","MediaTypes","Video","StartIndex",s.page*PAGE,"Limit",PAGE,"Fields","Overview,ParentId");
            else if(s.type.equals("next")) response=api.get("/Shows/NextUp","UserId",api.account.user,"StartIndex",s.page*PAGE,"Limit",PAGE,"Fields","Overview,ParentId");
            else if(s.type.equals("favorites")) response=api.get("/Users/"+api.account.user+"/Items","Recursive",true,"Filters","IsFavorite","IncludeItemTypes","Movie,Series,Episode","StartIndex",s.page*PAGE,"Limit",PAGE);
            else response=api.items(s.page*PAGE,PAGE,"Movie,Series,Episode",null,s.title);
            JSONArray a=Json.array(response,"Items"); db.put(a,System.currentTimeMillis()); return list(a);
        },n);
    }
    private void settings() {
        ScrollView scroll=new ScrollView(this); LinearLayout content=Ui.column(this); scroll.addView(content); body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        content.addView(Ui.text(this,"Wiedergabe",16,Ui.MUTED)); Ui.space(content,10);
        content.addView(Ui.button(this,"Auflösung: "+app.settings.getInt("height",720)+"p",()->choice("Maximale Auflösung",new String[]{"720p · HD, empfohlen","1080p · Full HD"},i->{ app.settings.edit().putInt("height",i==0?720:1080).apply(); show(screen,false); })));
        Ui.space(content,8); content.addView(Ui.button(this,"Bitrate: "+app.settings.getInt("bitrate",4000000)/1000000+" Mbit/s",()->choice("Maximale Bitrate",new String[]{"2 Mbit/s","4 Mbit/s","6 Mbit/s","8 Mbit/s"},i->{ app.settings.edit().putInt("bitrate",new int[]{2000000,4000000,6000000,8000000}[i]).apply(); show(screen,false); })));
        Ui.space(content,8); toggle(content,"Audio auf Stereo (2.0) heruntermischen","stereo",true);
        Ui.space(content,8); toggle(content,"Server-Transcoding bei Bedarf zulassen","serverFallback",false);
        Ui.space(content,8); toggle(content,"Nächste Folge automatisch","nextEpisode",true);
        Ui.space(content,8); toggle(content,"Intros und Outros automatisch überspringen","autoSkip",true);
        Ui.space(content,8); toggle(content,"Live TV beim Öffnen des Clients starten","liveOnLaunch",false);
        Ui.space(content,8); content.addView(Ui.button(this,"Live-TV-Aufnahmen",()->show(new Screen("recordings","Aufnahmen",null,null,null),true)));
        Ui.space(content,8); toggle(content,"Kleine Fokusanimationen","animations",true);
        Ui.space(content,20); content.addView(Ui.text(this,"Android-TV-Hauptmenü",16,Ui.MUTED)); Ui.space(content,10);
        content.addView(Ui.button(this,"Filme und Serien im TV-Hauptmenü: "+(app.settings.getBoolean("homeChannels",true)?"Ein":"Aus"),()-> {
            boolean enabled=!app.settings.getBoolean("homeChannels",true); app.settings.edit().putBoolean("homeChannels",enabled).apply();
            if(enabled) { app.channels.schedule(); app.channels.refresh(null); } else app.channels.cancelAndClear(); show(screen,false);
        })); Ui.space(content,8); content.addView(Ui.text(this,app.channels.status(),13,Ui.MUTED));
        for(String[] channel:new String[][]{{"resume","Weiterschauen"},{"next","Als Nächstes"},{"movies","Filme"},{"series","Serien"}}) {
            Ui.space(content,8); content.addView(Ui.button(this,"TV-Kanal aktivieren · "+channel[1],()->app.channels.requestVisible(this,channel[0])));
        }
        Ui.space(content,8); content.addView(Ui.text(this,"Der erste Kanal kann automatisch erscheinen. Weitere Reihen aktivierst du hier oder unter ‚Kanäle anpassen‘ im TV-Hauptmenü.\nDie Anzeige hängt vom Launcher ab; Google TV kann eigene Regeln verwenden.",13,Ui.MUTED));
        Ui.space(content,20); content.addView(Ui.text(this,"Bibliothekscache · Konto und Server getrennt",16,Ui.MUTED)); Ui.space(content,10);
        content.addView(Ui.text(this,app.library.state("cacheStatus"),14,Ui.MUTED)); Ui.space(content,10);
        content.addView(Ui.button(this,"Bibliothek und Cover vollständig vorladen",this::startCache)); Ui.space(content,8);
        content.addView(Ui.button(this,"Vorladen stoppen",()-> { stopService(new Intent(this,SyncService.class)); toast("Cache wird gestoppt"); })); Ui.space(content,8);
        int budget=app.settings.getInt("cacheMb",1024);
        content.addView(Ui.button(this,"Cover-Speicher: "+(budget==0?"gesamter freier Speicher":budget+" MB"),()->choice("Speicherbudget · 64 MB bleiben frei",new String[]{"256 MB","512 MB","1024 MB","2048 MB","4096 MB","Ohne feste Grenze"},i->{ app.settings.edit().putInt("cacheMb",new int[]{256,512,1024,2048,4096,0}[i]).apply(); show(screen,false); })));
        Ui.space(content,8); content.addView(Ui.button(this,"Covercache löschen",()-> { final Images images=app.images; app.io.execute(()-> { images.clear(); runOnUiThread(()->toast("Covercache gelöscht")); }); }));
        Ui.space(content,20); content.addView(Ui.text(this,"Angemeldet als "+app.account.name+" · "+app.account.server,14,Ui.MUTED)); Ui.space(content,8);
        content.addView(Ui.button(this,"Abmelden / Konto wechseln",()-> { app.logout(); history.clear(); login(""); }));
        Ui.space(content,18); content.addView(Ui.text(this,"Lowfin 0.1 · Intro Skipper über Jellyfin MediaSegments (10.10+)\nAndere Segmenttypen erscheinen als Skip-Taste. Medien werden vom Server abgespielt.\nDer erste Bibliothekslauf kann länger dauern; vorhandene Daten sind sofort nutzbar.",13,Ui.MUTED));
    }
    private void toggle(LinearLayout parent,String label,String key,boolean defaultValue) {
        boolean enabled=app.settings.getBoolean(key,defaultValue);
        parent.addView(Ui.button(this,label+": "+(enabled?"Ein":"Aus"),()-> { app.settings.edit().putBoolean(key,!enabled).apply(); show(screen,false); }));
    }
    private void choice(String title,String[] labels,java.util.function.IntConsumer action) { new AlertDialog.Builder(this).setTitle(title).setItems(labels,(d,w)->action.accept(w)).setNegativeButton("Abbrechen",null).show(); }
    private void startCache() { if(app.account!=null) { startForegroundService(new Intent(this,SyncService.class)); toast("Bibliothek wird im Hintergrund vorgeladen"); } }
    private void toast(String message) { Toast.makeText(this,message,Toast.LENGTH_LONG).show(); }
    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); if(app.account!=null&&hasHomeLink(intent)) handleHomeLink(intent); }
    private boolean hasHomeLink(Intent intent) { return intent!=null&&(intent.hasExtra(HomeChannels.EXTRA_ITEM)||(intent.getData()!=null&&"lowfin".equals(intent.getData().getScheme()))); }
    private void handleHomeLink(Intent intent) {
        String id=intent.getStringExtra(HomeChannels.EXTRA_ITEM),scope=intent.getStringExtra(HomeChannels.EXTRA_SCOPE),mode=intent.getStringExtra(HomeChannels.EXTRA_MODE);
        android.net.Uri data=intent.getData();
        if(data!=null&&"lowfin".equals(data.getScheme())&&"item".equals(data.getHost())) { id=data.getLastPathSegment(); scope=data.getQueryParameter("scope"); mode=data.getQueryParameter("mode"); }
        if(id==null||!id.matches("[a-zA-Z0-9_-]{1,80}")||scope==null||!scope.equals(app.account.scope())) { toast("Diese TV-Karte gehört zu einem anderen oder abgemeldeten Konto."); return; }
        final String itemId=id,action=mode==null?"open":mode; final Api api=app.api; final Library db=app.library; final int g=generation;
        // Consume once: a normal Activity recreation must not start it again.
        setIntent(new Intent(this,MainActivity.class));
        app.io.execute(()-> { try { JSONObject j=api.item(itemId); db.put(j);
            runOnUiThread(()-> { if(g!=generation||app.api!=api||isFinishing()) return; if(action.equals("play")) play(j,0); else if(action.equals("resume")) play(j,Json.position(j)); else open(j); });
        } catch(Exception e) { runOnUiThread(()-> { if(g==generation) toast("TV-Karte konnte nicht geöffnet werden: "+e.getMessage()); }); } });
    }
    @Override public void onBackPressed() {
        if(!history.isEmpty()) { Screen prev=history.pop(); screen=prev; generation++; shell(prev.title); switch(prev.kind) {
            case "seasons": seasons(prev.item); break; case "detail": detail(prev.item); break; case "live": live(); break; case "home": home(); break; case "settings":settings();break; case "recordings":recordings();break; default: renderCurrent();
        }} else super.onBackPressed();
    }
}
