package de.lowfin.tv;

import android.graphics.*;
import android.os.Looper;
import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.*;
import okhttp3.mockwebserver.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import java.io.*;
import java.util.function.BooleanSupplier;
import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=30,qualifiers="w960dp-h540dp-land-tvdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class TvUiTest {
    private ActivityController<MainActivity> activity;
    private MockWebServer server;
    private LowfinApp app;
    private JSONObject series;
    @Before public void setup() throws Exception {
        app=(LowfinApp)RuntimeEnvironment.getApplication(); series=Json.obj("Id","show","Type","Series","Name","Die lange Serie","Overview","45 Staffeln. Direkt zu deiner Lieblingsfolge.");
        server=new MockWebServer(); server.setDispatcher(new Dispatcher() {
            @Override public MockResponse dispatch(RecordedRequest request) {
                String path=request.getRequestUrl().encodedPath();
                if(path.equals("/Users/user/Views")) return new MockResponse().setBody(Json.obj("Items",Json.arr(Json.obj("Id","films","Name","Meine Filme","CollectionType","movies"),Json.obj("Id","shows","Name","Serien","CollectionType","tvshows"))).toString());
                if(path.equals("/LiveTv/Channels")) return new MockResponse().setBody(Json.obj("Items",Json.arr(Json.obj("Id","channel","Name","Sender Eins","Type","TvChannel")),"TotalRecordCount",1).toString());
                if(path.equals("/Shows/show/Seasons")) {
                    JSONArray seasons=new JSONArray(); for(int i=1;i<=45;i++) seasons.put(Json.obj("Id","s"+i,"ParentId","show","SeriesId","show","Type","Season","IndexNumber",i,"Name","Staffel "+i,"RecursiveItemCount",24));
                    return new MockResponse().setBody(Json.obj("Items",seasons,"TotalRecordCount",45).toString());
                }
                if(path.equals("/Users/user/Items")) return new MockResponse().setBody(Json.obj("Items",Json.arr(series),"TotalRecordCount",1).toString());
                if(path.equals("/Users/user/Items/show")) return new MockResponse().setBody(series.toString());
                if(path.endsWith("/Items/Resume")) return new MockResponse().setBody(Json.obj("Items",Json.arr(episode("ep5",5,6000000000L)),"TotalRecordCount",1).toString());
                if(path.equals("/Shows/NextUp")) return new MockResponse().setBody(Json.obj("Items",Json.arr(episode("ep6",6,0)),"TotalRecordCount",1).toString());
                if(path.endsWith("/Episodes")) return new MockResponse().setBody("{\"Items\":[],\"TotalRecordCount\":0}");
                return new MockResponse().setBody("{}");
            }
        }); server.start();
    }
    @After public void stop() throws Exception {
        if(activity!=null) activity.pause().stop().destroy();
        if(app.images!=null) app.images.close(); app.io.shutdownNow(); app.reports.shutdownNow(); server.shutdown();
    }
    @Test public void loginFitsAnHdScreenAndHasFocusableInputs() throws Exception {
        activity=Robolectric.buildActivity(MainActivity.class).setup(); layout();
        View root=activity.get().findViewById(android.R.id.content);
        Button login=findButton(root,"Anmelden"); assertNotNull(login); assertTrue(login.isFocusable());
        assertTrue(login.getBottom()<720); screenshot("login-hd.png");
    }
    @Test public void fortyFiveSeasonsAreVirtualizedAndStaffelFortyCanOpen() throws Exception {
        app.setAccount(new Account(server.url("/").toString(),"user","token","Rico","device")); app.library.state("lastSync",""+System.currentTimeMillis()); app.library.put(series);
        activity=Robolectric.buildActivity(MainActivity.class).setup(); layout();
        findButton(activity.get().findViewById(android.R.id.content),"Serien").performClick();
        await(()-> { RecyclerView r=recycler(); return r!=null&&r.getAdapter().getItemCount()==1; }); layout();
        RecyclerView grid=recycler(); assertTrue(grid.getChildCount()>0); grid.getChildAt(0).performClick();
        await(()-> { RecyclerView r=recycler(); return r!=null&&r.getAdapter().getItemCount()==45; });
        layout(); RecyclerView seasons=recycler(); assertEquals(45,seasons.getAdapter().getItemCount()); assertTrue(seasons.getChildCount()<45);
        LinearLayoutManager manager=(LinearLayoutManager)seasons.getLayoutManager(); manager.scrollToPositionWithOffset(39,0); layout();
        View row=manager.findViewByPosition(39); assertNotNull(row); assertTrue(((Button)row).getText().toString().startsWith("Staffel 40")); assertTrue(row.isFocusable());
        screenshot("seasons-40-hd.png"); row.performClick(); layout();
        assertNotNull(findText(activity.get().findViewById(android.R.id.content),"Staffel 40"));
    }
    @Test public void homeShowsResumeAndNextUpCardsAndResumesAtSavedPosition() throws Exception {
        app.setAccount(new Account(server.url("/").toString(),"user","token","Rico","device")); app.library.state("lastSync",""+System.currentTimeMillis());
        activity=Robolectric.buildActivity(MainActivity.class).setup();
        await(()-> { RecyclerView r=recycler(); return r!=null&&r.getAdapter() instanceof HomeAdapter&&((HomeAdapter)r.getAdapter()).rows.get(0).size()==1&&((HomeAdapter)r.getAdapter()).rows.get(1).size()==1; });
        layout(); RecyclerView home=recycler(); HomeAdapter adapter=(HomeAdapter)home.getAdapter();
        assertEquals("ep5",adapter.rows.get(0).get(0).optString("Id")); assertEquals("ep6",adapter.rows.get(1).get(0).optString("Id"));
        assertNotNull(findText(home,"Weiterschauen")); screenshot("home-hd.png");
        HomeAdapter.Shelf shelf=(HomeAdapter.Shelf)home.findViewHolderForAdapterPosition(0); assertNotNull(shelf); assertTrue(shelf.list.getChildCount()>0);
        shelf.list.getChildAt(0).performClick(); android.content.Intent intent=shadowOf(activity.get()).getNextStartedActivity(); assertNotNull(intent);
        assertEquals(600000L,intent.getLongExtra("position",-1)); assertEquals("ep5",new JSONObject(intent.getStringExtra("item")).optString("Id"));
    }
    @Test public void sidebarUsesActualLibraryNamesAndLiveTvOnlyShowsChannels() throws Exception {
        app.setAccount(new Account(server.url("/").toString(),"user","token","Rico","device")); app.library.state("lastSync",""+System.currentTimeMillis());
        activity=Robolectric.buildActivity(MainActivity.class).setup();
        await(()->findButton(activity.get().findViewById(android.R.id.content),"Meine Filme")!=null);
        View root=activity.get().findViewById(android.R.id.content);
        assertNotNull(findButton(root,"Suche")); findButton(root,"Live TV").performClick();
        await(()->recycler()!=null&&recycler().getAdapter().getItemCount()==1);
        assertNull(findButton(root,"Programm")); assertNull(findButton(root,"Aufnahmen"));
        screenshot("live-channels-hd.png");
    }
    private JSONObject episode(String id,int index,long position) { return Json.obj("Id",id,"Type","Episode","Name",index==5?"Der Rückweg":"Ein neuer Anfang","SeriesName","Die lange Serie","SeriesId","show","ParentIndexNumber",40,"IndexNumber",index,"RunTimeTicks",27000000000L,"UserData",Json.obj("PlaybackPositionTicks",position)); }
    @Test public void launcherSeriesLinkOpensItsSeasonsDirectly() throws Exception {
        Account account=new Account(server.url("/").toString(),"user","token","Rico","device"); app.setAccount(account); app.library.state("lastSync",""+System.currentTimeMillis());
        activity=Robolectric.buildActivity(MainActivity.class,HomeChannels.link(app,account,"show","open")).setup();
        await(()-> { RecyclerView r=recycler(); return r!=null&&r.getAdapter().getItemCount()==45; });
        assertNotNull(findText(activity.get().findViewById(android.R.id.content),"Die lange Serie"));
    }
    @Test public void launcherLinkFromAnotherAccountCannotStartPlayback() throws Exception {
        Account account=new Account(server.url("/").toString(),"user","token","Rico","device"); app.setAccount(account); app.library.state("lastSync",""+System.currentTimeMillis());
        Account other=new Account(server.url("/").toString(),"different-user","token","Other","device");
        activity=Robolectric.buildActivity(MainActivity.class,HomeChannels.link(app,other,"show","resume")).setup(); layout();
        assertNull(shadowOf(activity.get()).getNextStartedActivity());
    }
    private void await(BooleanSupplier condition) throws Exception {
        long end=System.currentTimeMillis()+8000;
        while(System.currentTimeMillis()<end) { shadowOf(Looper.getMainLooper()).idle(); layout(); if(condition.getAsBoolean()) return; Thread.sleep(20); }
        fail("UI data did not arrive");
    }
    private void layout() {
        shadowOf(Looper.getMainLooper()).idle(); View root=activity.get().getWindow().getDecorView();
        root.measure(View.MeasureSpec.makeMeasureSpec(1280,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY)); root.layout(0,0,1280,720); shadowOf(Looper.getMainLooper()).idle();
    }
    private void screenshot(String name) throws Exception {
        layout(); View root=activity.get().getWindow().getDecorView(); Bitmap bitmap=Bitmap.createBitmap(1280,720,Bitmap.Config.ARGB_8888); root.draw(new Canvas(bitmap));
        File dir=new File("build/qa"); dir.mkdirs(); try(OutputStream out=new FileOutputStream(new File(dir,name))) { bitmap.compress(Bitmap.CompressFormat.PNG,100,out); } bitmap.recycle();
    }
    private RecyclerView recycler() { return (RecyclerView)find(activity.get().findViewById(android.R.id.content),v->v instanceof RecyclerView); }
    private Button findButton(View root,String text) { return (Button)find(root,v->v instanceof Button&&text.equals(((Button)v).getText().toString())); }
    private TextView findText(View root,String text) { return (TextView)find(root,v->v instanceof TextView&&text.equals(((TextView)v).getText().toString())); }
    private View find(View root,java.util.function.Predicate<View> match) { if(match.test(root)) return root; if(root instanceof ViewGroup) for(int i=0;i<((ViewGroup)root).getChildCount();i++) { View r=find(((ViewGroup)root).getChildAt(i),match); if(r!=null) return r; } return null; }
}
