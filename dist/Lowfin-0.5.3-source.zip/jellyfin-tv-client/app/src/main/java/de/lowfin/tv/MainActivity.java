package de.lowfin.tv;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.*;
import org.json.*;
import java.util.*;

@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
public final class MainActivity extends Activity {
    private LowfinApp app;
    private FrameLayout root;
    private LinearLayout body,drawer;
    private FrameLayout contentStage;
    private View drawerShade,drawerReturnFocus,lastContentFocus;
    private Button menuButton;
    private boolean drawerOpen,drawerRightKey;
    private TextView status;
    private RecyclerView grid;
    private final Deque<Screen> history=new ArrayDeque<>();
    private Screen screen;
    private int generation;
    private Runnable homeReload;
    private LinearLayout sidebar;
    private final List<JSONObject> views=new ArrayList<>();
    private boolean viewsLoading;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable statusTick=new Runnable() { public void run() {
        if(status!=null) status.setText(app.syncing?app.syncStatus:screen!=null&&screen.kind.equals("settings")?app.syncStatus:app.account==null?"":app.account.name+"  ·  HD");
        handler.postDelayed(this,2000);
    }};
    private static final int PAGE=60;
    private static final class Screen {
        final String kind,title,type,parent; final JSONObject item;
        int page; Parcelable scroll;
        Screen(String kind,String title,String type,String parent,JSONObject item) { this.kind=kind; this.title=title; this.type=type; this.parent=parent; this.item=item; }
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); app=(LowfinApp)getApplication(); Ui.immersive(this);
        if(app.account==null) login(""); else {
            show(new Screen("home","Deine Bibliothek",null,null,null),false); checkSession();
            loadViews();
            String last=app.settings.getString("lastChannel","");
            if(hasHomeLink(getIntent())) handleHomeLink(getIntent());
            else if(savedNone(state)&&app.settings.getBoolean("liveOnLaunch",false)&&!last.isEmpty()) play(Json.obj("Id",last,"Type","TvChannel","Name","Live TV"),0);
        }
    }
    private boolean savedNone(Bundle state) { return state==null; }
    @Override protected void onResume() { super.onResume(); Ui.immersive(this); handler.post(statusTick); if(homeReload!=null&&screen!=null&&screen.kind.equals("home")) homeReload.run(); }
    @Override protected void onPause() { handler.removeCallbacks(statusTick); super.onPause(); }
    @Override protected void onDestroy() { generation++; handler.removeCallbacksAndMessages(null); super.onDestroy(); }
    private void checkSession() {
        final Api api=app.api;
        app.io.execute(()-> {
            try { api.get("/Users/Me");
                final Library db=app.library;
                app.cacheIo.execute(()-> {
                    String last=db.state("lastSync"); long time=0; try { time=Long.parseLong(last); } catch(Exception ignored) {}
                    final boolean due=System.currentTimeMillis()-time>24*60*60*1000L;
                    runOnUiThread(()-> { if(app.api==api&&!isFinishing()&&!app.syncing&&due) startCache(); });
                });
            } catch(Api.Failure e) { if(e.status==401||e.status==403) runOnUiThread(()-> { if(app.api==api) { app.logout(); history.clear(); login("Bitte erneut anmelden"); } }); }
            catch(Exception e) { runOnUiThread(()-> { if(app.api==api) toast("Server nicht erreichbar. Gespeicherte Bibliothek bleibt verfügbar."); }); }
        });
    }
    private void login(String error) {
        generation++; screen=null; grid=null;
        LinearLayout outer=Ui.column(this); outer.setGravity(Gravity.CENTER); outer.setBackgroundColor(Ui.BG);
        LinearLayout form=Ui.column(this); outer.addView(form,new LinearLayout.LayoutParams(Ui.dp(this,470),-2));
        form.addView(Ui.title(this,"LOWFIN",36)); Ui.space(form,8);
        form.addView(Ui.text(this,"Deine Medien. Direkt auf deinem TV.",17,Ui.MUTED)); Ui.space(form,24);
        EditText server=Ui.input(this,"Server · https://jellyfin.example",false);
        server.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);
        server.setText(app.settings.getString("lastServer","")); form.addView(server); Ui.space(form,10);
        EditText user=Ui.input(this,"Benutzername",false); form.addView(user); Ui.space(form,10);
        EditText password=Ui.input(this,"Passwort",true); form.addView(password); Ui.space(form,16);
        TextView hint=Ui.text(this,error,14,Ui.MUTED);
        Button signIn=Ui.button(this,"Anmelden",()-> {
            String address=server.getText().toString().trim().replaceAll("/+$","");
            okhttp3.HttpUrl u=okhttp3.HttpUrl.parse(address);
            if(u==null||u.host().isEmpty()||!u.username().isEmpty()||!u.password().isEmpty()||u.query()!=null||u.fragment()!=null) { hint.setText("Bitte eine vollständige Serveradresse ohne Zugangsdaten oder URL-Parameter angeben."); return; }
            String username=user.getText().toString().trim(),secret=password.getText().toString();
            if(username.isEmpty()) { hint.setText("Benutzername fehlt"); return; }
            hint.setText("Verbindung wird hergestellt …");
            final int g=generation;
            app.io.execute(()-> {
                try {
                    Api api=new Api(new Account(address,"","","",Account.device(this)));
                    JSONObject response=api.post("/Users/AuthenticateByName",Json.obj("Username",username,"Pw",secret));
                    JSONObject account=Json.object(response,"User");
                    Account a=new Account(address,account.getString("Id"),response.getString("AccessToken"),account.optString("Name",username),Account.device(this));
                    runOnUiThread(()-> { if(g!=generation||isFinishing()) return;
                        try { a.save(this); app.setAccount(a); app.settings.edit().putString("lastServer",address).apply(); password.setText("");
                            views.clear(); viewsLoading=false; show(new Screen("home","Deine Bibliothek",null,null,null),false); loadViews(); startCache(); if(hasHomeLink(getIntent())) handleHomeLink(getIntent());
                        } catch(Exception e) { hint.setText("Sitzung konnte nicht sicher gespeichert werden."); }
                    });
                } catch(Exception e) { runOnUiThread(()-> { if(g==generation) hint.setText(e instanceof Api.Failure?e.getMessage():"Verbindung fehlgeschlagen. Adresse und Netzwerk prüfen."); }); }
            });
        });
        form.addView(signIn); Ui.space(form,12); form.addView(hint);
        status=null; setContentView(outer); server.requestFocus();
    }
    private BackdropView detailBackdrop;
    private LinearLayout homeDescription;
    private TextView homeFilmTitle,homeFilmMeta,homeFilmOverview;
    private RatingsRow homeRatings;
    private Runnable ratingFocusUpdate;
    private int focusedHomeRow=-1;
    private String focusedHomeId="";
    private Runnable homeBackdropUpdate;
    private void shell(String title) {
        root=new FrameLayout(this); root.setBackgroundColor(Ui.BG); root.setPadding(Ui.dp(this,20),Ui.dp(this,18),Ui.dp(this,20),Ui.dp(this,18));
        drawerOpen=false; drawerReturnFocus=null; lastContentFocus=null;
        FrameLayout stage=new FrameLayout(this); contentStage=stage; root.addView(stage,new FrameLayout.LayoutParams(-1,-1)); detailBackdrop=null;
        if(screen!=null&&(screen.kind.equals("detail")||screen.kind.equals("home"))) {
            detailBackdrop=new BackdropView(this); stage.addView(detailBackdrop,new FrameLayout.LayoutParams(-1,-1));
            View shade=new View(this); shade.setBackground(new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xbd0c0c0d,0x660c0c0d})); stage.addView(shade,new FrameLayout.LayoutParams(-1,-1));
            View fade=new View(this); fade.setBackground(new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP,new int[]{0xef0c0c0d,0x200c0c0d})); stage.addView(fade,new FrameLayout.LayoutParams(-1,-1));
        }
        LinearLayout content=Ui.column(this); content.setPadding(Ui.dp(this,10),Ui.dp(this,4),Ui.dp(this,10),0); stage.addView(content,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout heading=Ui.row(this); menuButton=null; heading.addView(Ui.title(this,title,22)); content.addView(heading); Ui.space(content,8);
        body=Ui.column(this); content.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        drawerShade=new View(this); drawerShade.setBackgroundColor(0x99000000); drawerShade.setVisibility(View.GONE); drawerShade.setOnClickListener(v->setDrawer(false)); root.addView(drawerShade,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout left=Ui.column(this); drawer=left; left.setPadding(Ui.dp(this,14),Ui.dp(this,14),Ui.dp(this,14),Ui.dp(this,12)); left.setBackground(Ui.background(0xff111113,0));
        TextView brand=Ui.title(this,"LOWFIN",20); brand.setLetterSpacing(.12f); left.addView(brand); Ui.space(left,16);
        ScrollView menu=new ScrollView(this); menu.setVerticalScrollBarEnabled(false); sidebar=Ui.column(this); menu.addView(sidebar); left.addView(menu,new LinearLayout.LayoutParams(-1,0,1));
        Ui.space(left,12); status=Ui.text(this,"",12,Ui.MUTED); status.setMaxLines(3); left.addView(status);
        root.addView(left,new FrameLayout.LayoutParams(Ui.dp(this,214),-1,Gravity.START)); left.setVisibility(View.GONE);
        buildSidebar(); grid=null; setContentView(root);
        root.getViewTreeObserver().addOnGlobalFocusChangeListener((oldFocus,newFocus)-> {
            if(newFocus==null||newFocus==menuButton) return;
            for(android.view.ViewParent parent=newFocus.getParent();parent!=null;parent=parent.getParent()) if(parent==contentStage) { lastContentFocus=newFocus; break; }
        });
    }
    private void setDrawer(boolean open) {
        if(drawer==null||drawerOpen==open) return; drawerOpen=open; boolean animate=app.settings.getBoolean("animations",true);
        drawer.animate().cancel(); drawerShade.animate().cancel();
        if(open) {
            drawerReturnFocus=root.findFocus()==menuButton?lastContentFocus:root.findFocus(); contentStage.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
            drawer.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
            drawerShade.setVisibility(View.VISIBLE); drawer.setVisibility(View.VISIBLE);
            drawer.setTranslationX(animate?-Ui.dp(this,214):0); drawerShade.setAlpha(animate?0:1);
            if(animate) { drawer.animate().translationX(0).setDuration(140).start(); drawerShade.animate().alpha(1).setDuration(140).start(); }
            Button target=null;
            for(int i=0;i<sidebar.getChildCount();i++) if(sidebar.getChildAt(i) instanceof Button) { Button button=(Button)sidebar.getChildAt(i); if(target==null) target=button; if(Boolean.TRUE.equals(button.getTag())) { target=button; break; } }
            if(target!=null) {
                final Button selected=target; selected.requestFocus();
                drawer.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
                    @Override public void onLayoutChange(View view,int left,int top,int right,int bottom,int oldLeft,int oldTop,int oldRight,int oldBottom) {
                        view.removeOnLayoutChangeListener(this); view.post(()-> { if(drawerOpen&&selected.isShown()&&root.findFocus()==null) { selected.clearFocus(); selected.requestFocus(); } });
                    }
                });
            }
        } else {
            contentStage.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
            drawer.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
            if(animate) {
                drawer.animate().translationX(-Ui.dp(this,214)).setDuration(120).withEndAction(()-> { if(!drawerOpen) { drawer.setVisibility(View.GONE); drawer.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS); } }).start();
                drawerShade.animate().alpha(0).setDuration(120).withEndAction(()-> { if(!drawerOpen) drawerShade.setVisibility(View.GONE); }).start();
            } else { drawer.setVisibility(View.GONE); drawerShade.setVisibility(View.GONE); drawer.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS); }
            if(drawerReturnFocus!=null&&drawerReturnFocus!=menuButton&&drawerReturnFocus.isAttachedToWindow()&&drawerReturnFocus.isShown()) drawerReturnFocus.requestFocus();
            else if(grid!=null&&grid.getAdapter() instanceof HomeAdapter) ((HomeAdapter)grid.getAdapter()).requestRow(Math.max(0,focusedHomeRow));
            else if(grid!=null&&grid.getChildCount()>0) grid.getChildAt(0).requestFocus(); else if(body!=null) { body.setFocusable(true); body.requestFocus(); }
        }
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if(app.account!=null&&!drawerOpen&&grid==null&&event.getKeyCode()==KeyEvent.KEYCODE_DPAD_LEFT) { if(event.getAction()==KeyEvent.ACTION_DOWN) setDrawer(true); return true; }
        if(!drawerOpen&&grid!=null&&grid.getLayoutManager() instanceof GridLayoutManager&&event.getKeyCode()==KeyEvent.KEYCODE_DPAD_LEFT) {
            View focused=root.findFocus(); View card=focused==null?null:grid.findContainingItemView(focused); int position=card==null?RecyclerView.NO_POSITION:grid.getChildAdapterPosition(card);
            GridLayoutManager layout=(GridLayoutManager)grid.getLayoutManager();
            if(position!=RecyclerView.NO_POSITION&&layout.getSpanSizeLookup().getSpanIndex(position,layout.getSpanCount())==0) { if(event.getAction()==KeyEvent.ACTION_DOWN) setDrawer(true); return true; }
        }
        if(screen!=null&&event.getKeyCode()==KeyEvent.KEYCODE_MENU) { if(event.getAction()==KeyEvent.ACTION_DOWN&&event.getRepeatCount()==0) setDrawer(!drawerOpen); return true; }
        if(event.getKeyCode()==KeyEvent.KEYCODE_DPAD_RIGHT&&(drawerOpen||drawerRightKey)) {
            if(event.getAction()==KeyEvent.ACTION_DOWN) { drawerRightKey=true; setDrawer(false); } else drawerRightKey=false;
            return true;
        }
        if(drawerOpen&&(event.getKeyCode()==KeyEvent.KEYCODE_DPAD_UP||event.getKeyCode()==KeyEvent.KEYCODE_DPAD_DOWN||event.getKeyCode()==KeyEvent.KEYCODE_DPAD_LEFT)) {
            if(event.getAction()==KeyEvent.ACTION_DOWN&&event.getKeyCode()!=KeyEvent.KEYCODE_DPAD_LEFT) {
                List<Button> buttons=new ArrayList<>(); for(int i=0;i<sidebar.getChildCount();i++) if(sidebar.getChildAt(i) instanceof Button) buttons.add((Button)sidebar.getChildAt(i));
                int index=buttons.indexOf(root.findFocus()); int target=Math.max(0,Math.min(buttons.size()-1,index+(event.getKeyCode()==KeyEvent.KEYCODE_DPAD_UP?-1:1)));
                if(!buttons.isEmpty()) buttons.get(target).requestFocus();
            } return true;
        }
        if(!drawerOpen&&screen!=null&&screen.kind.equals("home")&&grid!=null&&grid.getAdapter() instanceof HomeAdapter&&focusedHomeRow>=0&&(event.getKeyCode()==KeyEvent.KEYCODE_DPAD_UP||event.getKeyCode()==KeyEvent.KEYCODE_DPAD_DOWN)) {
            if(event.getAction()==KeyEvent.ACTION_DOWN) ((HomeAdapter)grid.getAdapter()).moveRow(focusedHomeRow,event.getKeyCode()==KeyEvent.KEYCODE_DPAD_UP?-1:1);
            return true;
        }
        return super.dispatchKeyEvent(event);
    }
    private void sideButton(String label,Runnable action) {
        Button button=Ui.button(this,label,action); button.setGravity(Gravity.START|Gravity.CENTER_VERTICAL); button.setMaxLines(2); button.setEllipsize(android.text.TextUtils.TruncateAt.END);
        boolean selected=screen!=null&&(label.equals(screen.title)||label.equals("Start")&&screen.kind.equals("home")||label.equals("Suche")&&screen.kind.equals("search")&&screen.type.equals("term"));
        selected=selected||label.equals("Genres")&&screen!=null&&screen.kind.startsWith("genre");
        button.setTag(selected); Ui.navigation(button,selected); sidebar.addView(button,new LinearLayout.LayoutParams(-1,Ui.dp(this,39))); Ui.space(sidebar,3);
    }
    private void buildSidebar() {
        String focusedLabel=sidebar.findFocus() instanceof Button?((Button)sidebar.findFocus()).getText().toString():null;
        sidebar.removeAllViews(); sideButton("Start",()->show(new Screen("home","Deine Bibliothek",null,null,null),false)); sideButton("Suche",this::search); sideButton("Genres",()->show(new Screen("genres","Genres",null,null,null),false));
        Ui.space(sidebar,12); sideButton("Live TV",()->show(new Screen("live","Live TV",null,null,null),false));
        sideButton("Zufälliger Film",()-> { String parent=screen.kind.equals("browse")&&screen.type.contains("Movie")?screen.parent:null; setDrawer(false); randomMovie(parent); });
        sideButton("Genres anheften",()->show(new Screen("genres","Genres",null,null,null),false));
        if(screen.kind.equals("genre")) sideButton(HomeGenres.read(app.settings,app.account).contains(screen.parent)?"Von Startseite lösen":"Auf Startseite anheften",()-> { HomeGenres.toggle(app.settings,app.account,screen.parent); show(screen,false); });
        Ui.space(sidebar,12); sidebar.addView(Ui.text(this,"BIBLIOTHEKEN",11,Ui.MUTED)); Ui.space(sidebar,10);
        if(views.isEmpty()) {
            sideButton("Filme",()->show(new Screen("browse","Filme","Movie",null,null),false)); sideButton("Serien",()->show(new Screen("browse","Serien","Series",null,null),false));
        } else for(JSONObject library:views) {
            if("livetv".equals(library.optString("CollectionType"))) continue;
            sideButton(library.optString("Name"),()->show(new Screen("browse",library.optString("Name"),viewTypes(library),library.optString("Id"),library),false));
        }
        sideButton("Favoriten",()->special("Favoriten","favorites")); sideButton("Einstellungen",()->show(new Screen("settings","Einstellungen",null,null,null),false));
        if(drawerOpen&&focusedLabel!=null) for(int i=0;i<sidebar.getChildCount();i++) { View button=sidebar.getChildAt(i); if(button instanceof Button&&focusedLabel.equals(((Button)button).getText().toString())) { button.requestFocus(); break; } }
    }
    static String viewTypes(JSONObject library) { switch(library.optString("CollectionType")) { case "movies":return "Movie"; case "tvshows":return "Series"; case "homevideos":return "Video"; case "boxsets":return "BoxSet"; default:return "Movie,Series,Video,BoxSet"; } }
    private void loadViews() {
        if(viewsLoading||app.api==null) return; viewsLoading=true; final Api api=app.api; final Library db=app.library;
        final boolean[] fresh={false};
        app.cacheIo.execute(()-> {
            try { String saved=db.state("views"); if(!saved.isEmpty()) { List<JSONObject> cached=list(new JSONArray(saved));
                runOnUiThread(()-> { if(app.api==api&&sidebar!=null&&!fresh[0]) { views.clear(); views.addAll(cached); buildSidebar(); } });
            } } catch(Exception ignored) {}
        });
        app.navigationIo.execute(()-> {
            try { JSONArray a=Json.array(api.get("/Users/"+api.account.user+"/Views"),"Items"); List<JSONObject> result=list(a);
                runOnUiThread(()-> { if(app.api==api&&sidebar!=null) { fresh[0]=true; views.clear(); views.addAll(result); buildSidebar(); } });
                app.cacheIo.execute(()->db.state("views",a.toString()));
            } catch(Exception e) { runOnUiThread(()-> { if(app.api==api) toast("Bibliotheken konnten nicht aktualisiert werden: "+e.getMessage()); }); }
            finally { runOnUiThread(()-> { if(app.api==api) viewsLoading=false; }); }
        });
    }
    private void show(Screen next,boolean push) {
        if(push&&screen!=null) { if(grid!=null) screen.scroll=grid.getLayoutManager().onSaveInstanceState(); history.push(screen); }
        else if(!push) history.clear();
        if(homeBackdropUpdate!=null) handler.removeCallbacks(homeBackdropUpdate);
        focusedHomeRow=-1; focusedHomeId=""; homeDescription=null;
        screen=next; homeReload=null; generation++; shell(next.kind.equals("detail")?"Details":next.title);
        switch(next.kind) {
            case "home": home(); break;
            case "recommendations": recommendationItems(); break;
            case "browse": browse(); break;
            case "genres": genres(); break;
            case "genre": genreItems(); break;
            case "detail": detail(next.item); break;
            case "seasons": seasons(next.item); break;
            case "episodes": episodes(); break;
            case "live": live(); break;
            case "recordings": recordings(); break;
            case "settings": settings(); break;
            case "ratings": ratingSettings(); break;
            case "search": results(); break;
        }
    }
    private interface Work { List<JSONObject> run() throws Exception; }
    private void async(MediaAdapter adapter,Work work,TextView note) {
        int g=generation;
        (note==null?app.cacheIo:app.io).execute(()-> { try { List<JSONObject> data=work.run(); runOnUiThread(()-> { if(g!=generation||isFinishing()||(note==null&&adapter.fresh)) return;
            boolean first=adapter.items.isEmpty(); adapter.set(data); if(note!=null) { adapter.fresh=true; note.setText(data.isEmpty()?"Keine Einträge":""); } if(first) restoreFocus();
        }); } catch(Exception e) { runOnUiThread(()-> { if(g==generation&&note!=null) note.setText(adapter.items.isEmpty()?"Laden fehlgeschlagen: "+e.getMessage():"Gespeicherte Daten · Server aktuell nicht erreichbar"); }); } });
    }
    private static List<JSONObject> list(JSONArray a) { List<JSONObject> out=new ArrayList<>(); for(int i=0;i<a.length();i++) { JSONObject j=a.optJSONObject(i); if(j!=null) out.add(j); } return out; }
    private TextView note(String s) { TextView t=Ui.text(this,s,13,Ui.MUTED); body.addView(t); Ui.space(body,5); return t; }
    private MediaAdapter cards(boolean compact) {
        grid=new RecyclerView(this); int columns=8;
        GridLayoutManager layout=new GridLayoutManager(this,columns); grid.setLayoutManager(layout); grid.setItemAnimator(null); grid.setHasFixedSize(true); grid.setItemViewCacheSize(4);
        MediaAdapter adapter=new MediaAdapter(app.images,compact,this::open); adapter.onOpenMenu(()->setDrawer(true)); grid.setAdapter(adapter);
        layout.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() { @Override public int getSpanSize(int position) { return adapter.span(position); } });
        body.addView(grid,new LinearLayout.LayoutParams(-1,0,1)); return adapter;
    }
    private void restoreFocus() {
        if(grid==null) return;
        if(screen.scroll!=null) grid.getLayoutManager().onRestoreInstanceState(screen.scroll);
        grid.post(()-> { if(grid!=null&&grid.getChildCount()>0) grid.getChildAt(0).requestFocus(); });
    }
    private void home() {
        final List<String> pinned=HomeGenres.read(app.settings,app.account);
        grid=new RecyclerView(this) {
            @Override public boolean requestChildRectangleOnScreen(View child,android.graphics.Rect rect,boolean immediate) { return false; }
        }; grid.setLayoutManager(new LinearLayoutManager(this) {
            @Override public boolean onRequestChildFocus(RecyclerView parent,RecyclerView.State state,View child,View focused) { return true; }
            @Override public boolean requestChildRectangleOnScreen(RecyclerView parent,View child,android.graphics.Rect rect,boolean immediate,boolean keepFocusedChildVisible) { return false; }
        }); grid.setItemAnimator(null); grid.setItemViewCacheSize(1);
        final HomeAdapter[] holder=new HomeAdapter[1];
        HomeAdapter adapter=new HomeAdapter(app.images,pinned,(j,row)-> { if(row<2) play(j,row==0?Json.position(j):0); else open(j); },row->{
            if(row==0) special("Weiterschauen","resume"); else if(row==1) special("Als Nächstes","next");
            else if(HomeAdapter.recommendation(row)) show(new Screen("recommendations",holder[0].labels.get(row),null,null,Json.obj("Items",new JSONArray(holder[0].rows.get(row)))),true);
            else if(row>=HomeAdapter.GENRE_START) show(new Screen("genre",pinned.get(row-HomeAdapter.GENRE_START),"Movie,Series",pinned.get(row-HomeAdapter.GENRE_START),null),true);
            else show(new Screen("browse","Filme","Movie",null,null),true);
        },this::homeFocus,row->{ setHomeFocusMode(row); holder[0].requestRow(row); }); holder[0]=adapter; adapter.onOpenMenu(()->setDrawer(true));
        grid.setAdapter(adapter); body.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        homeDescription=Ui.column(this); homeDescription.setPadding(Ui.dp(this,5),Ui.dp(this,10),Ui.dp(this,14),0); homeDescription.setVisibility(View.GONE);
        homeFilmTitle=Ui.title(this,"",21); homeFilmTitle.setSingleLine(true); homeFilmTitle.setEllipsize(android.text.TextUtils.TruncateAt.END); homeDescription.addView(homeFilmTitle);
        homeFilmMeta=Ui.text(this,"",11,Ui.MUTED); homeDescription.addView(homeFilmMeta); Ui.space(homeDescription,6);
        homeRatings=new RatingsRow(this); homeDescription.addView(homeRatings); Ui.space(homeDescription,6);
        homeFilmOverview=Ui.text(this,"",14,0xffdddddf); homeFilmOverview.setMaxLines(3); homeFilmOverview.setEllipsize(android.text.TextUtils.TruncateAt.END); homeDescription.addView(homeFilmOverview,new LinearLayout.LayoutParams(-1,0,1));
        homeFilmOverview.addOnLayoutChangeListener((view,left,top,right,bottom,oldLeft,oldTop,oldRight,oldBottom)-> {
            int lines=Math.max(1,Math.min(5,(bottom-top-homeFilmOverview.getPaddingTop()-homeFilmOverview.getPaddingBottom())/Math.max(1,homeFilmOverview.getLineHeight())));
            if(homeFilmOverview.getMaxLines()!=lines) homeFilmOverview.setMaxLines(lines);
        });
        body.addView(homeDescription,new LinearLayout.LayoutParams(-1,0,1));
        final Api api=app.api; final Library db=app.library; final int g=generation; final boolean[] fresh=new boolean[HomeAdapter.GENRE_START+pinned.size()];
        app.cacheIo.execute(()-> {
            try { String stored=db.state("homeRecommendations"); if(!stored.isEmpty()) { List<JSONObject> cachedRecommendations=HomeRecommendations.select(new JSONArray(stored)); runOnUiThread(()-> { if(g==generation&&!fresh[2]) adapter.recommendations(cachedRecommendations); }); } } catch(Exception ignored) { }
            for(int i=0;i<fresh.length;i++) {
                if(HomeAdapter.recommendation(i)) continue;
                int row=i; List<JSONObject> cached=new ArrayList<>(); String stored=db.state(row<2?"home-"+row:"homeGenre-"+pinned.get(row-HomeAdapter.GENRE_START));
                try { if(!stored.isEmpty()) cached=list(new JSONArray(stored)); } catch(JSONException ignored) {}
                if(cached.isEmpty()&&row==0) cached=db.query("position>0 AND played=0",null,"stamp DESC",18,0);
                if(cached.isEmpty()&&row>=HomeAdapter.GENRE_START) cached=db.randomGenreMovies(pinned.get(row-HomeAdapter.GENRE_START),18);
                List<JSONObject> data=cached; runOnUiThread(()-> { if(g==generation&&!fresh[row]) adapter.update(row,data); });
            }
        });
        final long[] lastRefresh={0},lastGenreRefresh={0},lastRecommendationRefresh={0};
        homeReload=()-> {
            if(SystemClock.elapsedRealtime()-lastRefresh[0]<1500&&lastRefresh[0]!=0) return; lastRefresh[0]=SystemClock.elapsedRealtime();
            app.io.execute(()-> {
                for(int i=0;i<2;i++) { int row=i; try {
                    JSONObject response;
                    if(row==0) response=api.get("/Users/"+api.account.user+"/Items/Resume","MediaTypes","Video","Limit",18,"Fields","Overview,ParentId,PrimaryImageAspectRatio");
                    else response=api.get("/Shows/NextUp","UserId",api.account.user,"Limit",18,"Fields","Overview,ParentId,PrimaryImageAspectRatio","EnableResumable",false);
                    JSONArray a=Json.array(response,"Items"); db.put(a,System.currentTimeMillis()); db.state("home-"+row,a.toString()); List<JSONObject> data=list(a);
                    runOnUiThread(()-> { if(g==generation&&!isFinishing()) { fresh[row]=true; adapter.update(row,data); } });
                } catch(Exception ignored) { /* Cached shelves remain usable offline. */ } }
                app.channels.publish();
            });
            if(lastRecommendationRefresh[0]==0||SystemClock.elapsedRealtime()-lastRecommendationRefresh[0]>120000) {
                lastRecommendationRefresh[0]=SystemClock.elapsedRealtime();
                app.io.execute(()-> { if(g!=generation) return; try {
                    List<JSONObject> recommendations=HomeRecommendations.load(api);
                    for(JSONObject bucket:recommendations) db.put(Json.array(bucket,"Items"),System.currentTimeMillis());
                    db.state("homeRecommendations",new JSONArray(recommendations).toString());
                    runOnUiThread(()-> { if(g==generation&&!isFinishing()) { fresh[2]=true; adapter.recommendations(recommendations); app.channels.publish(); } });
                } catch(Exception ignored) { /* Account-scoped cached recommendations remain visible offline. */ } });
            }
            if(lastGenreRefresh[0]==0||SystemClock.elapsedRealtime()-lastGenreRefresh[0]>120000) {
                lastGenreRefresh[0]=SystemClock.elapsedRealtime();
                for(int i=0;i<pinned.size();i++) { final int row=HomeAdapter.GENRE_START+i; final String genre=pinned.get(i);
                    app.io.execute(()-> { if(g!=generation) return; try {
                        JSONArray items=Json.array(api.get("/Users/"+api.account.user+"/Items","Recursive",true,"IncludeItemTypes","Movie","Genres",genre,"SortBy","Random","Limit",18,"Fields","Overview,Genres,ProviderIds,ParentId,PrimaryImageAspectRatio"),"Items");
                        db.put(items,System.currentTimeMillis()); db.state("homeGenre-"+genre,items.toString()); List<JSONObject> data=list(items);
                        runOnUiThread(()-> { if(g==generation) { fresh[row]=true; adapter.update(row,data); } });
                    } catch(Exception ignored) { /* Preserve the cached random selection. */ } });
                }
            }
        }; homeReload.run();
    }
    private void setHomeFocusMode(int row) {
        if(grid==null||homeDescription==null||screen==null||!screen.kind.equals("home")) return;
        if(focusedHomeRow==row) return;
        boolean genre=row>=2; boolean changed=(focusedHomeRow>=2)!=genre; focusedHomeRow=row;
        ((HomeAdapter)grid.getAdapter()).setFocusedShelf(row);
        LinearLayout.LayoutParams size=(LinearLayout.LayoutParams)grid.getLayoutParams();
        size.height=genre?Ui.dp(this,244):0; size.weight=genre?0:1; grid.setLayoutParams(size);
        homeDescription.setVisibility(genre?View.VISIBLE:View.GONE);
        grid.setClipToPadding(false);
        if(genre) ((LinearLayoutManager)grid.getLayoutManager()).scrollToPositionWithOffset(row,0);
        else if(changed&&detailBackdrop!=null) { focusedHomeId=""; detailBackdrop.setTag(null); detailBackdrop.setImageDrawable(null); }
    }
    private void homeFocus(JSONObject film,int row) {
        if(row<0||screen==null||!screen.kind.equals("home")) return;
        boolean sameFilm=row==focusedHomeRow&&film!=null&&film.optString("Id").equals(focusedHomeId);
        setHomeFocusMode(row); if(sameFilm) return;
        if(homeBackdropUpdate!=null) handler.removeCallbacks(homeBackdropUpdate);
        if(row<2) return;
        focusedHomeId=film==null?"":film.optString("Id");
        if(film==null) { if(homeRatings!=null) homeRatings.clear(); homeFilmTitle.setText("Keine Filme in dieser Reihe"); homeFilmMeta.setText(""); homeFilmOverview.setText(""); if(detailBackdrop!=null) detailBackdrop.setImageDrawable(null); return; }
        renderHomeFilm(film); if(ratingFocusUpdate!=null) handler.removeCallbacks(ratingFocusUpdate); final RatingsRow badges=homeRatings; final int ratingGeneration=generation;
        badges.clear(); ratingFocusUpdate=()-> { if(ratingGeneration==generation&&film.optString("Id").equals(focusedHomeId)) badges.load(app,film); }; handler.postDelayed(ratingFocusUpdate,250);
        final int g=generation; final String id=focusedHomeId; final Images images=app.images;
        homeBackdropUpdate=()-> { if(g==generation&&id.equals(focusedHomeId)&&focusedHomeRow>=2&&detailBackdrop!=null) images.backdrop(detailBackdrop,film); };
        handler.postDelayed(homeBackdropUpdate,180);
    }
    private void renderHomeFilm(JSONObject film) {
        homeFilmTitle.setText(film.optString("Name"));
        List<String> facts=new ArrayList<>(); if(film.optInt("ProductionYear")>0) facts.add(""+film.optInt("ProductionYear"));
        if(film.optLong("RunTimeTicks")>0) facts.add(film.optLong("RunTimeTicks")/600000000+" min");
        if(!film.optString("OfficialRating").isEmpty()) facts.add(film.optString("OfficialRating")); homeFilmMeta.setText(String.join("  ·  ",facts));
        homeFilmOverview.setText(android.text.Html.fromHtml(film.optString("Overview","Keine Beschreibung vorhanden"),android.text.Html.FROM_HTML_MODE_LEGACY));
    }
    private void recommendationItems() {
        MediaAdapter adapter=cards(false); adapter.set(list(Json.array(screen.item,"Items"))); restoreFocus();
    }
    private void special(String title,String kind) {
        Screen s=new Screen("search",title,kind,null,null); show(s,true);
    }
    private void browse() {
        final Screen s=screen;
        TextView note=note("Wird geladen …"); MediaAdapter adapter=cards(false); pager();
        final Api api=app.api; final Library db=app.library;
        async(adapter,()->db.browse(s.type,s.parent,null,s.page*PAGE,PAGE),null);
        async(adapter,()-> { JSONArray a=Json.array(api.items(s.page*PAGE,PAGE,s.type,s.parent,null),"Items"); long stamp=System.currentTimeMillis(); db.put(a,stamp); if(s.parent!=null) db.link(s.parent,a,stamp); return list(a); },note);
    }
    private void genres() {
        TextView note=note("Genres werden geladen …"); grid=new RecyclerView(this); grid.setLayoutManager(new GridLayoutManager(this,3)); grid.setItemAnimator(null);
        GenreAdapter adapter=new GenreAdapter(genre->show(new Screen("genre",genre.optString("Name"),"Movie,Series",genre.optString("Name"),genre),true)); grid.setAdapter(adapter); body.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        final Api api=app.api; final Library db=app.library; final int g=generation; final boolean[] fresh={false};
        app.io.execute(()-> {
            List<JSONObject> saved=db.genres(); try { String state=db.state("genres"); if(!state.isEmpty()) saved=list(new JSONArray(state)); } catch(JSONException ignored) {}
            List<JSONObject> cached=saved; runOnUiThread(()-> { if(g==generation&&!fresh[0]) { adapter.set(cached); if(!cached.isEmpty()) note.setText(""); restoreFocus(); } });
            try { List<JSONObject> all=new ArrayList<>(); int offset=0;
                while(true) { JSONObject response=api.get("/Genres","UserId",api.account.user,"IncludeItemTypes","Movie,Series","StartIndex",offset,"Limit",200,"SortBy","SortName","SortOrder","Ascending","EnableImages",false); JSONArray page=Json.array(response,"Items"); all.addAll(list(page)); offset+=page.length(); if(page.length()==0||offset>=response.optInt("TotalRecordCount",offset)) break; }
                db.state("genres",new JSONArray(all).toString()); runOnUiThread(()-> { if(g==generation) { fresh[0]=true; adapter.set(all); note.setText(all.isEmpty()?"Keine Genres gefunden":""); restoreFocus(); } });
            } catch(Exception e) { runOnUiThread(()-> { if(g==generation) note.setText(adapter.items.isEmpty()?"Keine gespeicherten Genres · Server nicht erreichbar":"Gespeicherte Genres"); }); }
        });
    }
    private void genreItems() {
        final Screen s=screen;
        TextView note=note("Titel werden geladen …"); MediaAdapter adapter=cards(false); pager(); final Api api=app.api; final Library db=app.library;
        async(adapter,()->db.genreItems(s.parent,s.page*PAGE,PAGE),null);
        async(adapter,()-> { JSONArray items=Json.array(api.get("/Users/"+api.account.user+"/Items","Recursive",true,"IncludeItemTypes","Movie,Series","Genres",s.parent,"StartIndex",s.page*PAGE,"Limit",PAGE,"SortBy","SortName","SortOrder","Ascending","Fields","Overview,Genres,PrimaryImageAspectRatio"),"Items"); db.put(items,System.currentTimeMillis()); return list(items); },note);
    }
    private void randomMovie(String parent) {
        final Api api=app.api; final Library db=app.library; final int g=generation;
        List<String> names=new ArrayList<>(); if(grid!=null&&grid.getAdapter() instanceof MediaAdapter) for(JSONObject film:((MediaAdapter)grid.getAdapter()).items) if("Movie".equals(film.optString("Type"))) names.add(film.optString("Name"));
        MovieSlot slot=new MovieSlot(this,names); AlertDialog roulette=new AlertDialog.Builder(this).setView(slot).setNegativeButton("Abbrechen",null).create();
        roulette.setOnDismissListener(dialog->slot.stop()); roulette.show(); if(roulette.getWindow()!=null) roulette.getWindow().setLayout(Ui.dp(this,360),-2);
        app.io.execute(()-> {
            JSONObject chosen=null;
            try { chosen=Json.array(api.get("/Users/"+api.account.user+"/Items","Recursive",true,"IncludeItemTypes","Movie","ParentId",parent,"SortBy","Random","Limit",1,"Fields","Overview,Genres,PrimaryImageAspectRatio"),"Items").optJSONObject(0); if(chosen!=null) db.put(chosen); }
            catch(Exception e) { chosen=db.randomMovie(parent); }
            JSONObject film=chosen; runOnUiThread(()-> {
                if(g!=generation||isFinishing()||!roulette.isShowing()) { roulette.dismiss(); return; }
                if(film==null) { roulette.dismiss(); toast("Keine Filme in dieser Bibliothek gefunden"); }
                else slot.finish(film.optString("Name"),()-> { if(g==generation&&!isFinishing()&&roulette.isShowing()) { roulette.dismiss(); open(film); } });
            });
        });
    }
    private void pager() {
        LinearLayout row=Ui.row(this); Button prev=Ui.button(this,"← Vorherige Seite",()-> { if(screen.page>0) { screen.page--; screen.scroll=null; generation++; shell(screen.title); renderCurrent(); } }); prev.setEnabled(screen.page>0);
        Ui.addButton(row,prev); row.addView(Ui.text(this,"Seite "+(screen.page+1)+"  ·  60 Einträge  ",13,Ui.MUTED));
        Ui.addButton(row,Ui.button(this,"Nächste Seite →",()-> { screen.page++; screen.scroll=null; generation++; shell(screen.title); renderCurrent(); })); body.addView(row);
    }
    private void renderCurrent() { if(screen.kind.equals("genre")) genreItems(); else if(screen.kind.equals("genres")) genres(); else if(screen.kind.equals("episodes")) episodes(); else if(screen.kind.equals("search")) results(); else browse(); }
    private void open(JSONObject item) {
        String type=item.optString("Type");
        if(type.equals("Series")) show(new Screen("seasons",item.optString("Name"),null,item.optString("Id"),item),true);
        else if(type.equals("BoxSet")) show(new Screen("browse",item.optString("Name"),"Movie,Series",item.optString("Id"),item),true);
        else if(type.equals("Season")) show(new Screen("episodes",item.optString("Name"),"Episode",item.optString("Id"),item),true);
        else if(type.equals("TvChannel")) play(item,0);
        else show(new Screen("detail",Json.label(item),null,null,item),true);
    }
    private void seasons(JSONObject series) {
        LinearLayout controls=Ui.row(this);
        Ui.addButton(controls,Ui.button(this,"Seriendetails",()->show(new Screen("detail",series.optString("Name"),null,null,series),true)));
        TextView count=Ui.text(this,"Staffeln",12,Ui.MUTED); controls.addView(count,new LinearLayout.LayoutParams(0,-2,1));
        EditText number=Ui.input(this,"Staffel-Nr.",false); number.setTextSize(13); number.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        controls.addView(number,new LinearLayout.LayoutParams(Ui.dp(this,100),Ui.dp(this,36)));
        body.addView(controls); Ui.space(body,8);
        MediaAdapter adapter=cards(false); List<JSONObject> data=adapter.items;
        GridLayoutManager layout=(GridLayoutManager)grid.getLayoutManager(); RecyclerView seasons=grid;
        Ui.addButton(controls,Ui.button(this,"Zur Staffel",()-> { int target; try { target=Integer.parseInt(number.getText().toString()); } catch(Exception e) { return; }
            for(int i=0;i<data.size();i++) if(data.get(i).optInt("IndexNumber")==target) { int pos=i; layout.scrollToPositionWithOffset(pos,0); seasons.post(()-> { View v=layout.findViewByPosition(pos); if(v!=null) v.requestFocus(); }); return; }
            toast("Staffel nicht gefunden");
        }));
        final int g=generation; final Api api=app.api; final Library db=app.library; final String id=series.optString("Id"); final boolean[] fresh={false};
        app.io.execute(()-> {
            List<JSONObject> cached=db.query("type='Season' AND (parent=? OR series=?)",new String[]{id,id},"episode",500,0);
            runOnUiThread(()-> { if(g==generation&&!fresh[0]) { adapter.set(cached); count.setText(cached.size()+" Staffeln"); restoreFocus(); } });
            try { JSONArray a=Json.array(api.get("/Shows/"+id+"/Seasons","UserId",api.account.user,"Fields","Overview,ParentId,RecursiveItemCount,PrimaryImageAspectRatio"),"Items");
                List<JSONObject> all=list(a); all.sort(Comparator.comparingInt(j->j.optInt("IndexNumber"))); db.put(a,System.currentTimeMillis());
                runOnUiThread(()-> { if(g==generation) { fresh[0]=true; adapter.set(all); count.setText(all.size()+" Staffeln"); restoreFocus(); } });
            } catch(Exception e) { runOnUiThread(()-> { if(g==generation&&data.isEmpty()) toast("Staffeln konnten nicht geladen werden"); }); }
        });
    }
    private void episodes() {
        final Screen s=screen; TextView n=note("Folgen werden geladen …"); MediaAdapter adapter=cards(true); pager();
        final Api api=app.api; final Library db=app.library;
        async(adapter,()->db.browse("Episode",s.parent,null,s.page*PAGE,PAGE),null);
        async(adapter,()-> { String series=s.item.optString("SeriesId",s.item.optString("ParentId"));
            JSONArray a=Json.array(api.get("/Shows/"+series+"/Episodes","UserId",api.account.user,"SeasonId",s.parent,"StartIndex",s.page*PAGE,"Limit",PAGE,"Fields","Overview,MediaSources,MediaStreams,ParentId,PrimaryImageAspectRatio"),"Items");
            db.put(a,System.currentTimeMillis()); return list(a); },n);
    }
    private void detail(JSONObject original) {
        ScrollView page=new ScrollView(this); page.setFillViewport(true); page.setVerticalScrollBarEnabled(false);
        LinearLayout detail=Ui.column(this); detail.setPadding(0,Ui.dp(this,8),Ui.dp(this,8),Ui.dp(this,16)); page.addView(detail); body.addView(page,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout hero=Ui.row(this); hero.setGravity(Gravity.TOP); detail.addView(hero);
        ArtworkView image=new ArtworkView(this); image.ratio(Artwork.ratio(original,false)); image.crop(Artwork.crop(original,false));
        hero.addView(image,new LinearLayout.LayoutParams(Ui.dp(this,Artwork.ratio(original,false)>1?224:126),-2));
        LinearLayout content=Ui.column(this); content.setPadding(Ui.dp(this,22),0,0,0); hero.addView(content,new LinearLayout.LayoutParams(0,-2,1));
        TextView eyebrow=Ui.text(this,"",11,Ui.MUTED); eyebrow.setLetterSpacing(.12f); content.addView(eyebrow); Ui.space(content,5);
        TextView title=Ui.title(this,"",27); title.setMaxLines(2); title.setEllipsize(android.text.TextUtils.TruncateAt.END); content.addView(title); Ui.space(content,8);
        TextView meta=Ui.text(this,"",13,Ui.MUTED); content.addView(meta); Ui.space(content,8);
        TextView genres=Ui.text(this,"",12,Ui.MUTED); content.addView(genres); Ui.space(content,8);
        RatingsRow ratings=new RatingsRow(this); content.addView(ratings); Ui.space(content,12);
        LinearLayout playActions=Ui.row(this); content.addView(playActions); Ui.space(content,8);
        LinearLayout stateActions=Ui.row(this); content.addView(stateActions);
        Ui.space(detail,24); View divider=new View(this); divider.setBackgroundColor(0xff28282c); detail.addView(divider,new LinearLayout.LayoutParams(-1,Ui.dp(this,1))); Ui.space(detail,18);
        detail.addView(Ui.text(this,"ÜBER DIESEN TITEL",11,Ui.MUTED)); Ui.space(detail,8);
        TextView overview=Ui.text(this,"",14,0xffccccd1); overview.setLineSpacing(Ui.dp(this,3),1); detail.addView(overview);
        final JSONObject[] item={original}; final Runnable[] redraw=new Runnable[1];
        redraw[0]=()-> {
            JSONObject j=item[0]; ratings.load(app,j); boolean series="Series".equals(j.optString("Type")),episode="Episode".equals(j.optString("Type"));
            eyebrow.setText(series?"SERIE":episode?j.optString("SeriesName","FOLGE").toUpperCase(java.util.Locale.GERMAN):"FILM"); title.setText(j.optString("Name"));
            java.util.List<String> facts=new ArrayList<>(); if(episode) facts.add("Staffel "+j.optInt("ParentIndexNumber")+" · Folge "+j.optInt("IndexNumber"));
            if(j.optInt("ProductionYear")>0) facts.add(""+j.optInt("ProductionYear")); if(j.optLong("RunTimeTicks")>0) facts.add(j.optLong("RunTimeTicks")/600000000+" min"); if(!Json.str(j,"OfficialRating").isEmpty()) facts.add(Json.str(j,"OfficialRating"));
            meta.setText(String.join("  ·  ",facts)); java.util.List<String> names=new ArrayList<>(); JSONArray genre=Json.array(j,"Genres"); for(int i=0;i<Math.min(genre.length(),3);i++) names.add(genre.optString(i)); genres.setText(String.join("  /  ",names)); genres.setVisibility(names.isEmpty()?View.GONE:View.VISIBLE);
            if(detailBackdrop!=null) app.images.backdrop(detailBackdrop,j);
            overview.setText(j.optString("Overview","Keine Beschreibung vorhanden")); image.ratio(Artwork.ratio(j,false)); image.crop(Artwork.crop(j,false)); image.getLayoutParams().width=Ui.dp(this,Artwork.ratio(j,false)>1?224:126); app.images.show(image,j);
            int focusPlay=-1,focusState=-1; for(int i=0;i<playActions.getChildCount();i++) if(playActions.getChildAt(i).hasFocus()) focusPlay=i; for(int i=0;i<stateActions.getChildCount();i++) if(stateActions.getChildAt(i).hasFocus()) focusState=i;
            playActions.removeAllViews(); stateActions.removeAllViews();
            if(series) Ui.addButton(playActions,Ui.primary(this,"Staffeln ansehen",()->show(new Screen("seasons",j.optString("Name"),null,j.optString("Id"),j),true)));
            else if(Json.position(j)>0) { Ui.addButton(playActions,Ui.primary(this,"▶ Fortsetzen",()->play(j,Json.position(j)))); Ui.addButton(playActions,Ui.button(this,"Von vorn",()->play(j,0))); }
            else Ui.addButton(playActions,Ui.primary(this,"▶ Abspielen",()->play(j,0)));
            List<JSONObject> trailers=Trailers.youtube(j);
            if(!trailers.isEmpty()) Ui.addButton(playActions,Ui.button(this,"▶ Trailer",()->showTrailers(j,trailers)));
            boolean favorite=Json.object(j,"UserData").optBoolean("IsFavorite");
            Ui.addButton(stateActions,Ui.button(this,favorite?"★ Gespeichert":"☆ Merken",()->mutate(j,"/Users/"+app.account.user+"/FavoriteItems/"+j.optString("Id"),favorite?"DELETE":"POST",()->refreshItem(item,redraw[0]))));
            boolean played=Json.object(j,"UserData").optBoolean("Played");
            Ui.addButton(stateActions,Ui.button(this,played?"✓ Gesehen · ändern":"Als gesehen",()->mutate(j,"/Users/"+app.account.user+"/PlayedItems/"+j.optString("Id"),played?"DELETE":"POST",()->refreshItem(item,redraw[0]))));
            if(focusPlay>=0) playActions.getChildAt(Math.min(focusPlay,playActions.getChildCount()-1)).requestFocus();
            if(focusState>=0) stateActions.getChildAt(Math.min(focusState,stateActions.getChildCount()-1)).requestFocus();
        };
        redraw[0].run(); refreshItem(item,redraw[0]); playActions.getChildAt(0).requestFocus();
    }
    private void showTrailers(JSONObject film,List<JSONObject> trailers) {
        java.util.function.Consumer<JSONObject> launch=trailer->startActivity(new Intent(this,TrailerActivity.class).putExtra("videoId",trailer.optString("Id")).putExtra("title",film.optString("Name")+" · Trailer"));
        if(trailers.size()==1) launch.accept(trailers.get(0));
        else { String[] labels=new String[trailers.size()]; for(int i=0;i<labels.length;i++) labels[i]=trailers.get(i).optString("Name"); choice("Trailer wählen",labels,index->launch.accept(trailers.get(index))); }
    }
    private void refreshItem(JSONObject[] holder,Runnable render) {
        final int g=generation; final Api api=app.api; final Library db=app.library; String id=holder[0].optString("Id");
        app.io.execute(()-> { try { JSONObject j=api.item(id); db.put(j); runOnUiThread(()-> { if(g==generation) { holder[0]=j; render.run(); } }); } catch(Exception ignored) {} });
    }
    private void mutate(JSONObject item,String path,String method,Runnable after) {
        final Api api=app.api; int g=generation;
        app.io.execute(()-> { try { api.call(method,path,null); runOnUiThread(()-> { if(g==generation) after.run(); }); }
            catch(Exception e) { runOnUiThread(()-> { if(g==generation) toast(e.getMessage()); }); } });
    }
    private void play(JSONObject item,long position) {
        if(app.account==null) return;
        startActivity(new Intent(this,PlayerActivity.class).putExtra("item",item.toString()).putExtra("position",position));
    }
    private void live() {
        TextView n=note(""); MediaAdapter adapter=cards(true);
        final Api api=app.api; final Library db=app.library;
        async(adapter,()->db.browse("TvChannel",null,null,0,500),null);
        async(adapter,()-> { JSONArray a=Json.array(api.get("/LiveTv/Channels","UserId",api.account.user,"SortBy","SortName","Fields","ChannelInfo"),"Items"); db.put(a,System.currentTimeMillis()); return list(a); },n);
    }
    private void recordings() {
        TextView n=note("Aufnahmen werden geladen …"); MediaAdapter adapter=cards(true); final Api api=app.api;
        async(adapter,()->list(Json.array(api.get("/LiveTv/Recordings","UserId",api.account.user,"Fields","Overview,MediaSources,MediaStreams"),"Items")),n);
    }
    private void search() {
        EditText input=Ui.input(this,"Titel suchen",false);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Bibliothek durchsuchen").setView(input).setPositiveButton("Suchen",(d,w)->show(new Screen("search",input.getText().toString(),"term",null,null),true)).setNegativeButton("Abbrechen",null).create(); dialog.show(); input.requestFocus();
    }
    private void results() {
        final Screen s=screen; final Api api=app.api; final Library db=app.library;
        TextView n=note("Wird geladen …"); MediaAdapter adapter=cards(false); pager();
        async(adapter,()-> {
            if("resume".equals(s.type)) return db.query("position>0 AND played=0",null,"stamp DESC",PAGE,s.page*PAGE);
            if("favorites".equals(s.type)) return db.query("favorite=1",null,"name",PAGE,s.page*PAGE);
            return db.query("type IN ('Movie','Series','Episode') AND name LIKE ?",new String[]{"%"+s.title+"%"},"name",PAGE,s.page*PAGE);
        },null);
        async(adapter,()-> {
            JSONObject response;
            if(s.type.equals("resume")) response=api.get("/Users/"+api.account.user+"/Items/Resume","MediaTypes","Video","StartIndex",s.page*PAGE,"Limit",PAGE,"Fields","Overview,ParentId,PrimaryImageAspectRatio");
            else if(s.type.equals("next")) response=api.get("/Shows/NextUp","UserId",api.account.user,"StartIndex",s.page*PAGE,"Limit",PAGE,"Fields","Overview,ParentId,PrimaryImageAspectRatio");
            else if(s.type.equals("favorites")) response=api.get("/Users/"+api.account.user+"/Items","Recursive",true,"Filters","IsFavorite","IncludeItemTypes","Movie,Series,Episode","StartIndex",s.page*PAGE,"Limit",PAGE);
            else response=api.items(s.page*PAGE,PAGE,"Movie,Series,Episode",null,s.title);
            JSONArray a=Json.array(response,"Items"); db.put(a,System.currentTimeMillis()); return list(a);
        },n);
    }
    private void settings() {
        ScrollView scroll=new ScrollView(this); LinearLayout content=Ui.column(this); scroll.addView(content); body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        content.addView(Ui.button(this,"Bewertungen · Anbieter und API-Keys",()->show(new Screen("ratings","Bewertungen",null,null,null),true))); Ui.space(content,18);
        content.addView(Ui.text(this,"Wiedergabe",16,Ui.MUTED)); Ui.space(content,10);
        content.addView(Ui.button(this,"Auflösung: "+app.settings.getInt("height",720)+"p",()->choice("Maximale Auflösung",new String[]{"720p · HD, empfohlen","1080p · Full HD"},i->{ app.settings.edit().putInt("height",i==0?720:1080).apply(); show(screen,false); })));
        Ui.space(content,8); content.addView(Ui.button(this,"Bitrate: "+app.settings.getInt("bitrate",4000000)/1000000+" Mbit/s",()->choice("Maximale Bitrate",new String[]{"2 Mbit/s","4 Mbit/s","6 Mbit/s","8 Mbit/s"},i->{ app.settings.edit().putInt("bitrate",new int[]{2000000,4000000,6000000,8000000}[i]).apply(); show(screen,false); })));
        Ui.space(content,8); toggle(content,"Audio auf Stereo (2.0) heruntermischen","stereo",true);
        Ui.space(content,8); toggle(content,"Server-Transcoding bei Bedarf zulassen","serverFallback",false);
        Ui.space(content,8); int videoBudget=app.settings.getInt("videoCacheMb",500);
        content.addView(Ui.button(this,"Videocache: "+(videoBudget==0?"Aus":videoBudget+" MB"),this::videoCacheChoice));
        Ui.space(content,6); content.addView(Ui.text(this,"RAM-Puffer: automatisch · bis 48 MB, Live-TV bis 32 MB · mit Speicherreserve",12,Ui.MUTED));
        Ui.space(content,8); toggle(content,"Nächste Folge automatisch","nextEpisode",true);
        Ui.space(content,8); toggle(content,"Intros und Outros automatisch überspringen","autoSkip",true);
        Ui.space(content,8); toggle(content,"Live TV beim Öffnen des Clients starten","liveOnLaunch",false);
        Ui.space(content,8); content.addView(Ui.button(this,"Live-TV-Aufnahmen",()->show(new Screen("recordings","Aufnahmen",null,null,null),true)));
        Ui.space(content,8); toggle(content,"Kleine Fokusanimationen","animations",true);
        Ui.space(content,20); content.addView(Ui.text(this,"Android-TV-Hauptmenü",16,Ui.MUTED)); Ui.space(content,10);
        content.addView(Ui.button(this,"Filme und Serien im TV-Hauptmenü: "+(app.settings.getBoolean("homeChannels",true)?"Ein":"Aus"),()-> {
            boolean enabled=!app.settings.getBoolean("homeChannels",true); app.settings.edit().putBoolean("homeChannels",enabled).apply();
            if(enabled) { app.channels.schedule(); app.channels.refresh(null); } else app.channels.cancelAndClear(); show(screen,false);
        })); Ui.space(content,8); content.addView(Ui.text(this,app.channels.status(),13,Ui.MUTED));
        for(String[] channel:new String[][]{{"resume","Fortsetzen"},{"next","Als Nächstes"},{"movies","Filme"},{"series","Serien"}}) {
            Ui.space(content,8); content.addView(Ui.button(this,"TV-Kanal aktivieren · "+channel[1],()->app.channels.requestVisible(this,channel[0])));
        }
        for(int i=0;i<HomeRecommendations.ROWS;i++) {
            final String key="recommendation-"+i;
            Ui.space(content,8); content.addView(Ui.button(this,"TV-Kanal aktivieren · Film-Empfehlungen "+(i+1),()->app.channels.requestVisible(this,key)));
        }
        Ui.space(content,8); content.addView(Ui.text(this,"Der erste Kanal kann automatisch erscheinen. Weitere Reihen aktivierst du hier oder unter ‚Kanäle anpassen‘ im TV-Hauptmenü.\nDie Anzeige hängt vom Launcher ab; Google TV kann eigene Regeln verwenden.",13,Ui.MUTED));
        Ui.space(content,20); content.addView(Ui.text(this,"Bibliothekscache · Konto und Server getrennt",16,Ui.MUTED)); Ui.space(content,10);
        TextView cacheStatus=Ui.text(this,app.syncStatus,14,Ui.MUTED); content.addView(cacheStatus); Ui.space(content,10);
        final Library db=app.library; final int g=generation;
        app.cacheIo.execute(()-> { try { String saved=db.state("cacheStatus"); runOnUiThread(()-> { if(g==generation&&!saved.isEmpty()) cacheStatus.setText(saved); }); } catch(Exception ignored) {} });
        content.addView(Ui.button(this,"Bibliothek und Cover vollständig vorladen",this::startCache)); Ui.space(content,8);
        content.addView(Ui.button(this,"Vorladen stoppen",()-> { stopService(new Intent(this,SyncService.class)); toast("Cache wird gestoppt"); })); Ui.space(content,8);
        int budget=app.settings.getInt("cacheMb",1024);
        content.addView(Ui.button(this,"Cover-Speicher: "+(budget==0?"gesamter freier Speicher":budget+" MB"),()->choice("Speicherbudget · 64 MB bleiben frei",new String[]{"256 MB","512 MB","1024 MB","2048 MB","4096 MB","Ohne feste Grenze"},i->{ app.settings.edit().putInt("cacheMb",new int[]{256,512,1024,2048,4096,0}[i]).apply(); show(screen,false); })));
        Ui.space(content,8); content.addView(Ui.button(this,"Covercache löschen",()-> { final Images images=app.images; app.io.execute(()-> { images.clear(); runOnUiThread(()->toast("Covercache gelöscht")); }); }));
        Ui.space(content,20); content.addView(Ui.text(this,"Angemeldet als "+app.account.name+" · "+app.account.server,14,Ui.MUTED)); Ui.space(content,8);
        content.addView(Ui.button(this,"Abmelden / Konto wechseln",()-> { app.logout(); history.clear(); login(""); }));
        Ui.space(content,18); content.addView(Ui.text(this,"Lowfin 0.5.3 · Intro Skipper über Jellyfin MediaSegments (10.10+)\nAndere Segmenttypen erscheinen als Skip-Taste. Medien werden vom Server abgespielt.\nDer erste Bibliothekslauf kann länger dauern; vorhandene Daten sind sofort nutzbar.",13,Ui.MUTED));
    }
    private void ratingSettings() {
        ScrollView scroll=new ScrollView(this); LinearLayout content=Ui.column(this); scroll.addView(content); body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        content.addView(Ui.title(this,"Bewertungsanbieter",18)); Ui.space(content,8);
        for(String provider:new String[]{"omdb","mdblist","tmdb"}) {
            String name=provider.equals("omdb")?"OMDb":provider.equals("mdblist")?"MDBList":"TMDB";
            Button button=Ui.button(this,name+" · API-Key bearbeiten",()->ratingKeyDialog(provider,name));
            android.graphics.drawable.Drawable mark=getDrawable(provider.equals("tmdb")?R.drawable.rating_tmdb:provider.equals("omdb")?R.drawable.provider_omdb:R.drawable.provider_mdblist); RatingsRow.fitIcon(mark,this,26,18); button.setCompoundDrawables(mark,null,null,null); button.setCompoundDrawablePadding(Ui.dp(this,8));
            Ui.space(content,8); content.addView(button);
        }
        Ui.space(content,12); content.addView(Ui.text(this,"OMDb liefert IMDb, Rotten Tomatoes und Metacritic. MDBList ergänzt weitere Quellen. TMDB liefert die eigene Nutzerbewertung. Fehlende Werte werden ausgeblendet.",13,Ui.MUTED));
        Ui.space(content,20); content.addView(Ui.title(this,"Sichtbare Bewertungen",18));
        for(int i=0;i<Ratings.IDS.length;i++) { String id=Ratings.IDS[i],name=Ratings.NAMES[i]; Ui.space(content,6);
            Button button=Ui.button(this,name+": "+(Ratings.enabled(app.settings,id)?"Ein":"Aus"),()-> { app.settings.edit().putBoolean("rating-show-"+id,!Ratings.enabled(app.settings,id)).apply(); restartRatings(); show(screen,false); });
            int icon=RatingsRow.icon(id); if(icon!=0) { android.graphics.drawable.Drawable drawable=getDrawable(icon); RatingsRow.fitIcon(drawable,this,26,18); button.setCompoundDrawables(drawable,null,null,null); button.setCompoundDrawablePadding(Ui.dp(this,8)); } content.addView(button);
        }
        Ui.space(content,16); content.addView(Ui.text(this,app.ratings.status,12,Ui.MUTED));
        Ui.space(content,14); content.addView(Ui.text(this,"This product uses the TMDB API but is not endorsed or certified by TMDB.\nOMDb · www.omdbapi.com · Daten: CC BY-NC 4.0\nMDBList · mdblist.com",11,Ui.MUTED));
    }
    private void restartRatings() { if(app.ratings!=null) app.ratings.close(); app.ratings=new Ratings(this,app.library,app.api); }
    private void ratingKeyDialog(String provider,String name) {
        LinearLayout form=Ui.column(this); form.setPadding(Ui.dp(this,16),Ui.dp(this,8),Ui.dp(this,16),0);
        EditText input=Ui.input(this,name.equals("TMDB")?"API-Key oder Read Access Token":"API-Key",true); input.setSingleLine(true); form.addView(input);
        TextView hint=Ui.text(this,"API-Key wird verschlüsselt auf diesem Gerät gespeichert. Leeres Feld entfernt den Key.",12,Ui.MUTED); form.addView(hint);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(name+" verbinden").setView(form).setPositiveButton("Speichern",null).setNegativeButton("Abbrechen",null).create();
        final RatingKeys keys=new RatingKeys(this); app.io.execute(()-> { String saved=keys.get(provider); runOnUiThread(()-> { if(dialog.isShowing()&&input.getText().length()==0) input.setText(saved); }); });
        dialog.setOnShowListener(ignored->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(button->{ String value=input.getText().toString(); dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            app.io.execute(()-> { try { keys.put(provider,value); runOnUiThread(()-> { dialog.dismiss(); restartRatings(); if(screen.kind.equals("ratings")) show(screen,false); toast("API-Key gespeichert"); }); }
                catch(Exception e) { runOnUiThread(()-> { hint.setText("API-Key konnte nicht sicher gespeichert werden."); dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true); }); } });
        })); dialog.show();
    }
    private void videoCacheChoice() {
        int[] values={0,128,256,500,1024,2048};
        choice("Videocache auf dem Gerätespeicher",new String[]{"Aus","128 MB","256 MB","500 MB","1024 MB","2048 MB","Eigener Wert …"},index->{
            if(index<values.length) { app.settings.edit().putInt("videoCacheMb",values[index]).apply(); show(screen,false); return; }
            EditText input=Ui.input(this,"Größe in MB",false); input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); input.setText(""+app.settings.getInt("videoCacheMb",500));
            AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Videocache in MB").setView(input).setPositiveButton("Speichern",null).setNegativeButton("Abbrechen",null).create();
            dialog.setOnShowListener(ignored->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(button->{
                try { int size=Integer.parseInt(input.getText().toString()); if(size<16||size>16384) { input.setError("16 bis 16384 MB eingeben"); return; }
                    app.settings.edit().putInt("videoCacheMb",size).apply(); dialog.dismiss(); show(screen,false);
                } catch(NumberFormatException e) { input.setError("Eine Größe in MB eingeben"); }
            })); dialog.show();
        });
    }
    private void toggle(LinearLayout parent,String label,String key,boolean defaultValue) {
        boolean enabled=app.settings.getBoolean(key,defaultValue);
        parent.addView(Ui.button(this,label+": "+(enabled?"Ein":"Aus"),()-> { app.settings.edit().putBoolean(key,!enabled).apply(); show(screen,false); }));
    }
    private void choice(String title,String[] labels,java.util.function.IntConsumer action) { new AlertDialog.Builder(this).setTitle(title).setItems(labels,(d,w)->action.accept(w)).setNegativeButton("Abbrechen",null).show(); }
    private void startCache() { if(app.account!=null) { startForegroundService(new Intent(this,SyncService.class)); toast("Bibliothek wird im Hintergrund vorgeladen"); } }
    private void toast(String message) { Toast.makeText(this,message,Toast.LENGTH_LONG).show(); }
    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); if(app.account!=null&&hasHomeLink(intent)) handleHomeLink(intent); }
    private boolean hasHomeLink(Intent intent) { return intent!=null&&(intent.hasExtra(HomeChannels.EXTRA_ITEM)||(intent.getData()!=null&&"lowfin".equals(intent.getData().getScheme()))); }
    private void handleHomeLink(Intent intent) {
        String id=intent.getStringExtra(HomeChannels.EXTRA_ITEM),scope=intent.getStringExtra(HomeChannels.EXTRA_SCOPE),mode=intent.getStringExtra(HomeChannels.EXTRA_MODE);
        android.net.Uri data=intent.getData();
        if(data!=null&&"lowfin".equals(data.getScheme())&&"item".equals(data.getHost())) { id=data.getLastPathSegment(); scope=data.getQueryParameter("scope"); mode=data.getQueryParameter("mode"); }
        if(id==null||!id.matches("[a-zA-Z0-9_-]{1,80}")||scope==null||!scope.equals(app.account.scope())) { toast("Diese TV-Karte gehört zu einem anderen oder abgemeldeten Konto."); return; }
        final String itemId=id,action=mode==null?"open":mode; final Api api=app.api; final Library db=app.library; final int g=generation;
        // Consume once: a normal Activity recreation must not start it again.
        setIntent(new Intent(this,MainActivity.class));
        app.io.execute(()-> { try { JSONObject j=api.item(itemId); db.put(j);
            runOnUiThread(()-> { if(g!=generation||app.api!=api||isFinishing()) return; if(action.equals("play")) play(j,0); else if(action.equals("resume")) play(j,Json.position(j)); else open(j); });
        } catch(Exception e) { runOnUiThread(()-> { if(g==generation) toast("TV-Karte konnte nicht geöffnet werden: "+e.getMessage()); }); } });
    }
    private AlertDialog exitDialog;
    private void confirmExit() {
        if(exitDialog!=null&&exitDialog.isShowing()) return;
        exitDialog=new AlertDialog.Builder(this).setTitle("Lowfin beenden?").setMessage("Möchtest du die App wirklich beenden?")
            .setPositiveButton("Beenden",(dialog,which)->finish()).setNegativeButton("Weiter ansehen",null).create();
        exitDialog.setOnShowListener(dialog->{ Button stay=exitDialog.getButton(AlertDialog.BUTTON_NEGATIVE); stay.setFocusableInTouchMode(true); stay.requestFocus(); stay.post(stay::requestFocus); }); exitDialog.show();
    }
    @Override public void onBackPressed() {
        if(drawerOpen) { setDrawer(false); return; }
        if(!history.isEmpty()) { Screen prev=history.pop(); screen=prev; generation++; shell(prev.title); switch(prev.kind) {
            case "seasons": seasons(prev.item); break; case "detail": detail(prev.item); break; case "live": live(); break; case "home": home(); break;
            case "recommendations": recommendationItems(); break; case "settings":settings();break; case "ratings":ratingSettings();break; case "recordings":recordings();break; default: renderCurrent();
        }} else if(app.account!=null&&screen!=null&&!screen.kind.equals("home")) {
            show(new Screen("home","Deine Bibliothek",null,null,null),false);
        } else if(screen!=null&&screen.kind.equals("home")&&focusedHomeRow>=2) {
            setHomeFocusMode(0); ((HomeAdapter)grid.getAdapter()).requestRow(0);
        } else confirmExit();
    }
}
