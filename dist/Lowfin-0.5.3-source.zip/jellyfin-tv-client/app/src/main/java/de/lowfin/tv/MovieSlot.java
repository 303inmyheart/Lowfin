package de.lowfin.tv;

import android.content.Context;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Three recycled text rows form a reel; no bitmap churn or unbounded animation. */
final class MovieSlot extends LinearLayout {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final LinearLayout reel;
    private final TextView status;
    private final Jackpot jackpot;
    private final List<String> labels;
    private int index;
    private boolean stopped,finishing;
    private long started;
    private final Runnable spin=new Runnable() { @Override public void run() {
        if(stopped||finishing) return;
        reel.animate().translationY(-Ui.dp(getContext(),28)).setDuration(100).withEndAction(()-> {
            if(stopped||finishing) return; index++; bind(); reel.setTranslationY(0); handler.postDelayed(this,35);
        }).start();
    }};
    MovieSlot(Context context,List<String> names) {
        super(context); labels=new ArrayList<>(names); if(labels.isEmpty()) labels.addAll(Arrays.asList("Ein neuer Favorit","Etwas Überraschendes","Dein nächster Film"));
        setOrientation(VERTICAL); setPadding(Ui.dp(context,22),Ui.dp(context,18),Ui.dp(context,22),Ui.dp(context,18));
        addView(Ui.title(context,"Filmroulette",18)); Ui.space(this,14);
        FrameLayout window=new FrameLayout(context); window.setClipChildren(true); window.setBackground(Ui.background(0xff141416,0));
        reel=Ui.column(context); for(int i=0;i<4;i++) { TextView text=Ui.text(context,"",16,Color.WHITE); text.setSingleLine(true); text.setEllipsize(android.text.TextUtils.TruncateAt.END); text.setGravity(Gravity.CENTER); reel.addView(text,new LayoutParams(-1,Ui.dp(context,28))); }
        window.addView(reel,new FrameLayout.LayoutParams(-1,-2));
        View marker=new View(context); marker.setBackground(Ui.background(0x16ffffff,0xff55555b)); FrameLayout.LayoutParams center=new FrameLayout.LayoutParams(-1,Ui.dp(context,28)); center.topMargin=Ui.dp(context,28); window.addView(marker,center);
        FrameLayout stage=new FrameLayout(context); FrameLayout.LayoutParams slotSize=new FrameLayout.LayoutParams(-1,Ui.dp(context,84),Gravity.CENTER); stage.addView(window,slotSize);
        jackpot=new Jackpot(context); stage.addView(jackpot,new FrameLayout.LayoutParams(-1,-1));
        addView(stage,new LayoutParams(-1,Ui.dp(context,120))); Ui.space(this,12);
        status=Ui.text(context,"Ein Film wird ausgewählt …",12,Ui.MUTED); status.setGravity(Gravity.CENTER); addView(status); bind(); started=SystemClock.elapsedRealtime(); handler.post(spin);
    }
    private void bind() { for(int row=0;row<4;row++) { TextView text=(TextView)reel.getChildAt(row); text.setText(labels.get((index+row)%labels.size())); text.setAlpha(row==1?1:.35f); } }
    void finish(String name,Runnable opened) {
        if(stopped) return; long delay=Math.max(0,4000-(SystemClock.elapsedRealtime()-started));
        handler.postDelayed(()-> {
            if(stopped) return; finishing=true; handler.removeCallbacks(spin); reel.animate().cancel(); reel.setTranslationY(-Ui.dp(getContext(),28));
            ((TextView)reel.getChildAt(1)).setText(name); ((TextView)reel.getChildAt(1)).setAlpha(1); status.setText("✦  DEIN TREFFER  ✦"); jackpot.start();
            reel.animate().translationY(0).setDuration(280).start();
            handler.postDelayed(()-> { if(!stopped) opened.run(); },900);
        },delay);
    }
    /** One short canvas animation with a fixed number of silver sparks. */
    private static final class Jackpot extends View {
        private final android.graphics.Paint paint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private android.animation.ValueAnimator animator;
        private float fraction;
        Jackpot(Context context) { super(context); setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO); }
        void start() {
            if(!getContext().getSharedPreferences("settings",0).getBoolean("animations",true)) return;
            animator=android.animation.ValueAnimator.ofFloat(0,1); animator.setDuration(850);
            animator.addUpdateListener(a->{ fraction=(float)a.getAnimatedValue(); invalidate(); }); animator.start();
        }
        @Override protected void onDraw(android.graphics.Canvas canvas) {
            if(animator==null||fraction>=1) return;
            paint.setColor(0xffeeeeee); paint.setAlpha((int)((1-fraction)*220)); paint.setStrokeWidth(Ui.dp(getContext(),2));
            float cx=getWidth()/2f,cy=getHeight()/2f,r=getHeight()*(.2f+fraction*.5f);
            for(int i=0;i<16;i++) { double angle=i*Math.PI/8; float x=(float)Math.cos(angle),y=(float)Math.sin(angle); canvas.drawLine(cx+x*r,cy+y*r,cx+x*(r+12*(1-fraction)),cy+y*(r+12*(1-fraction)),paint); }
            paint.setStyle(android.graphics.Paint.Style.STROKE); canvas.drawRoundRect(getWidth()*.08f,cy-Ui.dp(getContext(),16),getWidth()*.92f,cy+Ui.dp(getContext(),16),8,8,paint); paint.setStyle(android.graphics.Paint.Style.FILL);
        }
        void stop() { if(animator!=null) animator.cancel(); fraction=1; }
    }
    @Override protected void onDetachedFromWindow() { stop(); super.onDetachedFromWindow(); }
    void stop() { stopped=true; handler.removeCallbacksAndMessages(null); reel.animate().cancel(); jackpot.stop(); }
}
