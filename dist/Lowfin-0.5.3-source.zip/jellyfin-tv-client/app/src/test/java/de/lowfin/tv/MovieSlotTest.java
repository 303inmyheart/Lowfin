package de.lowfin.tv;

import android.app.Activity;
import android.os.Looper;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import java.time.Duration;
import java.util.Arrays;
import static org.junit.Assert.*;
import static org.robolectric.Shadows.shadowOf;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=30)
@LooperMode(LooperMode.Mode.PAUSED)
public class MovieSlotTest {
    @Test public void rouletteWaitsFourSecondsAndOpensExactlyOnceAfterCelebration() {
        ActivityController<Activity> activity=Robolectric.buildActivity(Activity.class).setup();
        MovieSlot slot=new MovieSlot(activity.get(),Arrays.asList("Film A","Film B")); activity.get().setContentView(slot);
        int[] opened={0}; slot.finish("Film B",()->opened[0]++);
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(3999)); assertEquals(0,opened[0]);
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(1001)); assertEquals(1,opened[0]);
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(2)); assertEquals(1,opened[0]);
        activity.pause().stop().destroy();
    }
    @Test public void canceledRouletteCannotOpenItsPendingFilm() {
        ActivityController<Activity> activity=Robolectric.buildActivity(Activity.class).setup();
        MovieSlot slot=new MovieSlot(activity.get(),Arrays.asList("Film A","Film B")); activity.get().setContentView(slot);
        int[] opened={0}; slot.finish("Film B",()->opened[0]++); slot.stop(); shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(5));
        assertEquals(0,opened[0]); activity.pause().stop().destroy();
    }
}
