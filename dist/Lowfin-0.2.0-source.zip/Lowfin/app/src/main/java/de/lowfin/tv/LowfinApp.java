package de.lowfin.tv;

import android.app.Application;
import android.content.SharedPreferences;
import java.util.concurrent.*;

public final class LowfinApp extends Application {
    final ExecutorService io=Executors.newFixedThreadPool(2);
    final ExecutorService reports=Executors.newSingleThreadExecutor();
    Account account; Api api; Library library; Images images;
    HomeChannels channels;
    SharedPreferences settings;
    volatile String syncStatus="Cache noch nicht erstellt";
    volatile boolean syncing=false,playing=false;
    @Override public void onCreate() { super.onCreate(); settings=getSharedPreferences("settings",0); channels=new HomeChannels(this); setAccount(Account.load(this)); }
    synchronized void setAccount(Account a) {
        if(images!=null) images.close();
        account=a;
        if(a!=null) { api=new Api(a); library=new Library(this,a.scope()); images=new Images(this,api,a.scope()); }
        else { api=null; library=null; images=null; }
        if(a!=null&&channels!=null) channels.schedule();
    }
    void logout() {
        stopService(new android.content.Intent(this,SyncService.class));
        channels.cancelAndClear();
        if(api!=null) { Api previous=api; previous.http.dispatcher().cancelAll(); reports.execute(()-> { try { previous.post("/Sessions/Logout",null); } catch(Exception ignored) {} }); }
        Account.clear(this); setAccount(null);
    }
}
