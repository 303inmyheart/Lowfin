package de.lowfin.tv;

import android.app.*;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.media3.common.*;
import androidx.media3.exoplayer.*;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.datasource.okhttp.OkHttpDataSource;
import androidx.media3.ui.PlayerView;
import okhttp3.HttpUrl;
import org.json.*;
import java.util.*;
import java.util.concurrent.*;

@androidx.media3.common.util.UnstableApi
public final class PlayerActivity extends Activity {
    private LowfinApp app;
    private Api api;
    private Library library;
    private JSONObject item,source;
    private JSONArray segments=new JSONArray();
    private final Set<String> skipped=new HashSet<>();
    private PlayerView view;
    private ExoPlayer player;
    private LinearLayout toolbar;
    private TextView message,title;
    private Button skip;
    private long skipTarget,requestedPosition;
    private int audio=-1,subtitle=-1;
    private volatile int generation;
    private String sourceId,sessionId,liveId,method="DirectPlay";
    private boolean live,started,forceHls,released;
    private final ExecutorService network=Executors.newSingleThreadExecutor();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private long lastReport;
    private final Runnable tick=new Runnable() { @Override public void run() {
        if(released||player==null) return;
        if(player.getPlaybackState()==Player.STATE_READY) {
            long position=player.getCurrentPosition();
            if(!live) applySegments(position);
            if(started&&SystemClock.elapsedRealtime()-lastReport>=10000) { report("/Progress",position); lastReport=SystemClock.elapsedRealtime(); }
        }
        handler.postDelayed(this,500);
    }};
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved); app=(LowfinApp)getApplication(); library=app.library;
        if(app.account==null) { released=true; finish(); return; }
        api=new Api(app.account);
        try { item=new JSONObject(getIntent().getStringExtra("item")); } catch(Exception e) { finish(); return; }
        requestedPosition=saved!=null?saved.getLong("position"):getIntent().getLongExtra("position",0);
        live="TvChannel".equals(item.optString("Type"));
        app.playing=true; getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); Ui.immersive(this);
        layout(); load(requestedPosition,false);
    }
    private void layout() {
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
        view=new PlayerView(this); view.setKeepContentOnPlayerReset(true); view.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING); view.setControllerShowTimeoutMs(4000);
        view.setShowSubtitleButton(false); root.addView(view,new FrameLayout.LayoutParams(-1,-1));
        toolbar=Ui.column(this); toolbar.setBackgroundColor(0xe6101010); toolbar.setPadding(Ui.dp(this,24),Ui.dp(this,10),Ui.dp(this,24),Ui.dp(this,10));
        title=Ui.title(this,Json.label(item),18); title.setSingleLine(true); toolbar.addView(title);
        LinearLayout options=Ui.row(this); Ui.space(toolbar,5); HorizontalScrollView optionsScroll=new HorizontalScrollView(this); optionsScroll.setHorizontalScrollBarEnabled(false); optionsScroll.addView(options); toolbar.addView(optionsScroll);
        Ui.addButton(options,Ui.button(this,"Ton",()->streams("Audio")));
        Ui.addButton(options,Ui.button(this,"Untertitel",()->streams("Subtitle")));
        Ui.addButton(options,Ui.button(this,"Version",this::versions));
        Ui.addButton(options,Ui.button(this,"Kapitel",this::chapters));
        Ui.addButton(options,Ui.button(this,"Über Server abspielen",()-> { long p=position(); forceHls=true; load(p,true); }));
        if(live) {
            Ui.addButton(options,Ui.button(this,"Sender",this::channels));
            Ui.addButton(options,Ui.button(this,"Programm",this::guide));
        } else if("Episode".equals(item.optString("Type"))) Ui.addButton(options,Ui.button(this,"Nächste Folge",()->nextEpisode(false)));
        FrameLayout.LayoutParams top=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP); root.addView(toolbar,top);
        message=Ui.text(this,"Stream wird geöffnet …",18,Color.WHITE); message.setGravity(Gravity.CENTER); message.setPadding(24,24,24,24); message.setBackgroundColor(0xe6101010);
        FrameLayout.LayoutParams center=new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER); root.addView(message,center);
        skip=Ui.button(this,"Überspringen",()-> { if(player!=null) { player.seekTo(skipTarget); skip.setVisibility(View.GONE); view.requestFocus(); } }); skip.setVisibility(View.GONE);
        FrameLayout.LayoutParams skipLayout=new FrameLayout.LayoutParams(-2,Ui.dp(this,48),Gravity.END|Gravity.BOTTOM); skipLayout.setMargins(0,0,Ui.dp(this,35),Ui.dp(this,100)); root.addView(skip,skipLayout);
        view.setControllerVisibilityListener((PlayerView.ControllerVisibilityListener)visibility->{ if(toolbar!=null&&!toolbar.hasFocus()) toolbar.setVisibility(visibility); });
        setContentView(root); view.requestFocus();
    }
    private void load(long position,boolean keepSelections) {
        cleanupSession(); final int g=++generation; started=false; requestedPosition=position; segments=new JSONArray(); skipped.clear(); skip.setVisibility(View.GONE);
        if(player!=null) { view.setPlayer(null); player.release(); player=null; }
        message.setVisibility(View.VISIBLE); message.setText("Stream wird geöffnet …"); title.setText(Json.label(item));
        final String id=item.optString("Id"); final boolean isLive=live;
        final String requestedSource=sourceId; final int requestedAudio=audio,requestedSubtitle=subtitle; final boolean force=forceHls;
        if(isLive) app.settings.edit().putString("lastChannel",id).apply();
        network.execute(()-> {
            JSONObject negotiated=null,chosen=null; String negotiatedLive=null,negotiatedSession=null;
            try {
                if(g!=generation||released) return;
                JSONObject detailed=api.item(id);
                int audioIndex=requestedAudio,subtitleIndex=requestedSubtitle;
                if(!keepSelections) {
                    JSONArray sources=Json.array(detailed,"MediaSources");
                    JSONObject first=sources.optJSONObject(0);
                    for(int i=0;i<sources.length();i++) { JSONObject s=sources.optJSONObject(i); if(s!=null&&Json.str(s,"Id").equals(requestedSource)) first=s; }
                    if(first!=null) { audioIndex=first.optInt("DefaultAudioStreamIndex",-1); subtitleIndex=first.optInt("DefaultSubtitleStreamIndex",-1); }
                }
                if(g!=generation||released) return;
                JSONObject request=PlaybackPolicy.request(api.account.user,app.settings.getInt("height",720),app.settings.getInt("bitrate",4000000),isLive,force,position,audioIndex,subtitleIndex,requestedSource,app.settings.getBoolean("stereo",true));
                if(!force) { LocalPlayback.negotiate(request); request.put("EnableTranscoding",app.settings.getBoolean("serverFallback",false)); }
                negotiated=api.post("/Items/"+id+"/PlaybackInfo",request,"UserId",api.account.user);
                if(!Json.str(negotiated,"ErrorCode").isEmpty()) throw new IllegalStateException("Wiedergabe nicht möglich: "+Json.str(negotiated,"ErrorCode"));
                JSONArray sources=Json.array(negotiated,"MediaSources"); chosen=sources.optJSONObject(0);
                if(chosen==null) throw new IllegalStateException("Keine abspielbare Medienquelle");
                negotiatedLive=Json.str(chosen,"LiveStreamId"); negotiatedSession=Json.str(negotiated,"PlaySessionId");
                if(chosen.optBoolean("RequiresOpening")&&negotiatedLive.isEmpty()) throw new IllegalStateException("Jellyfin hat den Live-Stream nicht geöffnet");
                String playMethod="DirectPlay",stream;
                boolean hls=false;
                if((isLive||force||!chosen.optBoolean("SupportsDirectPlay"))&&!Json.str(chosen,"TranscodingUrl").isEmpty()) {
                    stream=resolve(Json.str(chosen,"TranscodingUrl")); playMethod=chosen.optString("TranscodingSubProtocol").equals("hls")||stream.contains("m3u8")?"Transcode":"DirectStream"; hls=stream.contains("m3u8");
                    HttpUrl.Builder url=HttpUrl.get(stream).newBuilder();
                    if(!isLive) { url.removeAllQueryParameters("startTimeTicks"); url.setQueryParameter("StartTimeTicks","0"); }
                    if(force||app.settings.getBoolean("serverFallback",false)) { int height=app.settings.getInt("height",720); url.setQueryParameter("MaxWidth",height==720?"1280":"1920"); url.setQueryParameter("MaxHeight",""+height); }
                    if(force&&app.settings.getBoolean("stereo",true)) { url.setQueryParameter("MaxAudioChannels","2"); url.setQueryParameter("AudioChannels","2"); }
                    stream=url.build().toString();
                } else if(!force&&(chosen.optBoolean("SupportsDirectPlay")||chosen.optBoolean("SupportsDirectStream"))) {
                    playMethod=chosen.optBoolean("SupportsDirectPlay")&&!isLive?"DirectPlay":"DirectStream";
                    stream=api.url("/Videos/"+id+"/stream","Static",true,"MediaSourceId",chosen.optString("Id"),"LiveStreamId",negotiatedLive.isEmpty()?null:negotiatedLive,
                        "DeviceId",api.account.device,"PlaySessionId",negotiatedSession).toString();
                } else throw new IllegalStateException("Kein direkt abspielbarer Stream. Optional ‚Über Server abspielen‘ wählen.");
                JSONObject full=detailed,src=chosen; String url=stream,playSession=negotiatedSession,liveStream=negotiatedLive,mode=playMethod; boolean useHls=hls;
                final int selectedAudio=audioIndex,selectedSubtitle=subtitleIndex;
                library.put(full);
                runOnUiThread(()-> {
                    if(g!=generation||released) { closeNegotiated(liveStream,playSession); return; }
                    item=full; source=src; sourceId=src.optString("Id"); sessionId=playSession; liveId=liveStream; method=mode;
                    audio=selectedAudio; subtitle=selectedSubtitle; prepare(url,useHls,isLive?0:position,g);
                    app.channels.engaged(api.account,id);
                });
                if(!isLive) { try {
                    JSONArray found=Json.array(api.get("/MediaSegments/"+id),"Items"); library.state("segments-"+id,found.toString());
                    runOnUiThread(()-> { if(g==generation&&!released) segments=found; });
                } catch(Exception e) {
                    String cached=library.state("segments-"+id); if(!cached.isEmpty()) { JSONArray found=new JSONArray(cached); runOnUiThread(()-> { if(g==generation&&!released) segments=found; }); }
                }}
            } catch(Exception e) {
                closeNegotiated(negotiatedLive,negotiatedSession);
                runOnUiThread(()-> { if(g==generation&&!released) { message.setVisibility(View.VISIBLE); message.setText("Stream konnte nicht gestartet werden.\n"+friendly(e)+"\nZurück oder ‚Über Server abspielen‘ wählen."); view.showController(); } });
            }
        });
    }
    private String resolve(String value) {
        HttpUrl parsed=HttpUrl.get(api.account.server+"/").resolve(value);
        HttpUrl base=HttpUrl.get(api.account.server);
        if(parsed==null||!parsed.host().equals(base.host())||parsed.port()!=base.port()||!parsed.scheme().equals(base.scheme())) throw new IllegalArgumentException("Streamadresse außerhalb des Jellyfin-Servers");
        // Jellyfin returns /Videos/... even when hosted below /jellyfin.
        if(value.startsWith("/")&&!base.encodedPath().equals("/")&&!parsed.encodedPath().startsWith(base.encodedPath()+"/")) return api.account.server+value;
        return parsed.toString();
    }
    private String friendly(Exception e) { return e instanceof Api.Failure?e.getMessage():e instanceof java.io.IOException?"Verbindung zum Server prüfen":e.getMessage(); }
    private void prepare(String url,boolean hls,long position,int g) {
        OkHttpDataSource.Factory data=new OkHttpDataSource.Factory(api.http).setDefaultRequestProperties(Collections.singletonMap("Authorization",api.authorization()));
        DefaultLoadControl control=new DefaultLoadControl.Builder().setBufferDurationsMs(8000,20000,1200,2500).setTargetBufferBytes(8*1024*1024).setPrioritizeTimeOverSizeThresholds(false).build();
        player=new ExoPlayer.Builder(this,LocalPlayback.renderers(this,app.settings.getBoolean("stereo",true))).setMediaSourceFactory(new DefaultMediaSourceFactory(data)).setLoadControl(control).build();
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setMaxVideoSize(app.settings.getInt("height",720)==720?1280:1920,app.settings.getInt("height",720))
            .setMaxVideoFrameRate(30).setMaxAudioChannelCount(6).setPreferredAudioLanguages("de","en").setPreferredTextLanguages("de").build());
        player.setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),true);
        player.setHandleAudioBecomingNoisy(true); view.setPlayer(player);
        MediaItem.Builder media=new MediaItem.Builder().setUri(url); if(hls) media.setMimeType(MimeTypes.APPLICATION_M3U8);
        if(subtitle>=0) {
            JSONArray streams=Json.array(source,"MediaStreams");
            for(int i=0;i<streams.length();i++) { JSONObject s=streams.optJSONObject(i); if(s==null||s.optInt("Index",-2)!=subtitle||!s.optString("Type").equals("Subtitle")) continue;
                if(s.optString("DeliveryMethod").equals("External")&&!s.optString("DeliveryUrl").isEmpty()) {
                    String codec=s.optString("Codec"); String mime=codec.equals("vtt")?MimeTypes.TEXT_VTT:MimeTypes.APPLICATION_SUBRIP;
                    try { media.setSubtitleConfigurations(Collections.singletonList(new MediaItem.SubtitleConfiguration.Builder(Uri.parse(resolve(s.optString("DeliveryUrl"))))
                        .setMimeType(mime).setLanguage(s.optString("Language")).setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build())); } catch(Exception ignored) {}
                }
            }
        }
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if(g!=generation||released) return;
                if(state==Player.STATE_READY) {
                    message.setVisibility(View.GONE);
                    if(!started) { started=true; report("",player.getCurrentPosition()); lastReport=SystemClock.elapsedRealtime(); }
                }
                if(state==Player.STATE_ENDED&&!live) {
                    if(app.settings.getBoolean("nextEpisode",true)&&"Episode".equals(item.optString("Type"))) nextEpisode(true);
                    else { message.setText("Wiedergabe beendet"); message.setVisibility(View.VISIBLE); view.showController(); }
                }
            }
            @Override public void onPlayerError(PlaybackException error) {
                if(g!=generation||released) return;
                if(!forceHls&&app.settings.getBoolean("serverFallback",false)) { long p=Math.max(requestedPosition,position()); forceHls=true; message.setText("Kompatibler Serverstream wird versucht …"); load(p,true); }
                else { message.setText("Wiedergabefehler: "+error.getErrorCodeName()+"\nZurück oder erneut ‚Über Server abspielen‘ wählen."); message.setVisibility(View.VISIBLE); view.showController(); }
            }
        });
        player.setMediaItem(media.build(),position); player.prepare(); player.setPlayWhenReady(true);
        handler.removeCallbacks(tick); handler.post(tick);
    }
    private long position() { return player==null?requestedPosition:Math.max(0,player.getCurrentPosition()); }
    private void applySegments(long position) {
        boolean offer=false;
        for(int i=0;i<segments.length();i++) {
            JSONObject s=segments.optJSONObject(i); if(s==null||!PlaybackPolicy.active(s,position)) continue;
            String type=s.optString("Type"),key=s.optString("Id",type+":"+s.optLong("StartTicks")); long end=s.optLong("EndTicks")/10000;
            if(PlaybackPolicy.automatic(type)&&app.settings.getBoolean("autoSkip",true)) {
                if(skipped.add(key)) { long duration=player.getDuration(); player.seekTo(duration>0?Math.min(end,duration):end); }
                continue;
            }
            offer=true; skipTarget=end; String label=type.equals("Recap")?"Rückblick":type.equals("Preview")?"Vorschau":type.equals("Commercial")?"Werbung":type.equals("Intro")?"Intro":type.equals("Outro")?"Outro":type;
            skip.setText(label+" überspringen"); skip.setVisibility(View.VISIBLE); break;
        }
        if(!offer) { if(skip.hasFocus()) view.requestFocus(); skip.setVisibility(View.GONE); }
    }
    private JSONObject reportBody(long pos) {
        return Json.obj("ItemId",item.optString("Id"),"MediaSourceId",sourceId,"PlaySessionId",sessionId,"PositionTicks",pos*10000,
            "IsPaused",player==null||!player.isPlaying(),"IsMuted",player!=null&&player.getVolume()==0,"CanSeek",!live,
            "PlayMethod",method,"AudioStreamIndex",audio,"SubtitleStreamIndex",subtitle,"EventName","TimeUpdate","PlaybackStartTimeTicks",0);
    }
    private void report(String endpoint,long pos) {
        if(sessionId==null||sessionId.isEmpty()) return; final JSONObject body=reportBody(pos);
        app.reports.execute(()-> { try { api.report(endpoint,body); } catch(Exception ignored) {} });
    }
    private void cleanupSession() {
        if(sessionId!=null) {
            report("/Stopped",position());
            JSONObject cached=item; long pos=position(),duration=player==null?0:player.getDuration();
            try { JSONObject user=Json.object(cached,"UserData"); user.put("PlaybackPositionTicks",pos*10000); if(duration>0&&pos>duration*.95) { user.put("Played",true); user.put("PlaybackPositionTicks",0); } cached.put("UserData",user); library.put(cached); } catch(Exception ignored) {}
            closeNegotiated(liveId,sessionId);
        }
        sessionId=null; liveId=null;
    }
    private void closeNegotiated(String liveStream,String session) {
        if((liveStream==null||liveStream.isEmpty())&&(session==null||session.isEmpty())) return;
        app.reports.execute(()-> {
            if(liveStream!=null&&!liveStream.isEmpty()) try { api.post("/LiveStreams/Close",null,"LiveStreamId",liveStream); } catch(Exception ignored) {}
            if(session!=null&&!session.isEmpty()) try { api.call("DELETE","/Videos/ActiveEncodings",null,"DeviceId",api.account.device,"PlaySessionId",session); } catch(Exception ignored) {}
        });
    }
    private void streams(String type) {
        if(source==null) return; List<String> names=new ArrayList<>(); List<Integer> indices=new ArrayList<>();
        if(type.equals("Subtitle")) { names.add("Aus"); indices.add(-1); }
        JSONArray streams=Json.array(source,"MediaStreams");
        for(int i=0;i<streams.length();i++) { JSONObject s=streams.optJSONObject(i); if(s==null||!type.equals(s.optString("Type"))) continue;
            names.add(s.optString("DisplayTitle",s.optString("Language","Spur "+s.optInt("Index")))); indices.add(s.optInt("Index"));
        }
        if(names.isEmpty()) { toast("Keine weiteren Spuren"); return; }
        new AlertDialog.Builder(this).setTitle(type.equals("Audio")?"Tonspur":"Untertitel").setItems(names.toArray(new String[0]),(d,w)-> { long p=position(); if(type.equals("Audio")&&method.equals("DirectPlay")&&selectLocalAudio(indices.get(w))) { audio=indices.get(w); return; } if(type.equals("Audio")) audio=indices.get(w); else subtitle=indices.get(w); forceHls=app.settings.getBoolean("serverFallback",false); load(p,true); }).setNegativeButton("Abbrechen",null).show();
    }
    private boolean selectLocalAudio(int streamIndex) {
        if(player==null||source==null) return false;
        int ordinal=0,target=-1; JSONArray streams=Json.array(source,"MediaStreams");
        for(int i=0;i<streams.length();i++) { JSONObject stream=streams.optJSONObject(i); if(stream==null||!"Audio".equals(stream.optString("Type"))) continue; if(stream.optInt("Index",-1)==streamIndex) target=ordinal; ordinal++; }
        if(target<0) return false; ordinal=0;
        for(Tracks.Group group:player.getCurrentTracks().getGroups()) if(group.getType()==C.TRACK_TYPE_AUDIO) for(int track=0;track<group.length;track++) {
            if(ordinal++==target) { if(!group.isTrackSupported(track)) return false;
                player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setOverrideForType(new TrackSelectionOverride(group.getMediaTrackGroup(),track)).build()); return true;
            }
        }
        return false;
    }
    private void versions() {
        JSONArray sources=Json.array(item,"MediaSources"); if(sources.length()<2) { toast("Eine Medienversion vorhanden"); return; }
        String[] labels=new String[sources.length()]; for(int i=0;i<sources.length();i++) labels[i]=sources.optJSONObject(i).optString("Name","Version "+(i+1));
        new AlertDialog.Builder(this).setTitle("Medienversion").setItems(labels,(d,w)-> { sourceId=sources.optJSONObject(w).optString("Id"); forceHls=false; load(position(),false); }).show();
    }
    private void chapters() {
        JSONArray chapters=Json.array(item,"Chapters"); if(chapters.length()==0) { toast("Keine Kapitel"); return; }
        String[] labels=new String[chapters.length()]; for(int i=0;i<chapters.length();i++) labels[i]=chapters.optJSONObject(i).optString("Name","Kapitel "+(i+1));
        new AlertDialog.Builder(this).setTitle("Kapitel").setItems(labels,(d,w)-> { if(player!=null) player.seekTo(chapters.optJSONObject(w).optLong("StartPositionTicks")/10000); }).show();
    }
    private void nextEpisode(boolean automatic) {
        if(!"Episode".equals(item.optString("Type"))) return;
        final String id=item.optString("Id"),series=item.optString("SeriesId"); int g=generation;
        network.execute(()-> { try {
            JSONObject next=library.next(item);
            // Resolve from server so an incompletely cached library cannot skip an episode.
            JSONArray episodes=Json.array(api.get("/Shows/"+series+"/Episodes","UserId",api.account.user,"StartItemId",id,"Limit",2,"Fields","Overview,ParentId"),"Items");
            if(episodes.length()>1&&id.equals(episodes.optJSONObject(0).optString("Id"))) next=episodes.optJSONObject(1);
            else if(episodes.length()==1&&id.equals(episodes.optJSONObject(0).optString("Id"))) next=null;
            JSONObject chosen=next;
            runOnUiThread(()-> { if(g!=generation||released) return; if(chosen==null) { toast("Keine weitere Folge"); if(automatic) finish(); return; }
                cleanupSession(); item=chosen; sourceId=null; forceHls=false; load(0,false);
            });
        } catch(Exception e) { runOnUiThread(()-> { if(g==generation) toast("Nächste Folge konnte nicht geladen werden"); }); } });
    }
    private void channels() {
        int g=generation;
        network.execute(()-> { try { List<JSONObject> list=new ArrayList<>(); JSONArray channels=Json.array(api.get("/LiveTv/Channels","UserId",api.account.user,"SortBy","SortName"),"Items");
            String[] labels=new String[channels.length()]; for(int i=0;i<channels.length();i++) { JSONObject c=channels.optJSONObject(i); list.add(c); labels[i]=c.optString("ChannelNumber")+"  "+c.optString("Name"); }
            runOnUiThread(()-> { if(g!=generation||released) return; new AlertDialog.Builder(this).setTitle("Sender wechseln").setItems(labels,(d,w)->switchChannel(list.get(w))).setNegativeButton("Abbrechen",null).show(); });
        } catch(Exception e) { runOnUiThread(()->toast("Senderliste nicht verfügbar")); } });
    }
    private void switchChannel(JSONObject channel) { cleanupSession(); item=channel; live=true; sourceId=null; forceHls=false; load(0,false); }
    private void zap(int direction) {
        int g=generation; String id=item.optString("Id");
        network.execute(()-> { try {
            JSONArray channels=Json.array(api.get("/LiveTv/Channels","UserId",api.account.user,"SortBy","SortName"),"Items");
            for(int i=0;i<channels.length();i++) if(id.equals(channels.optJSONObject(i).optString("Id"))) { JSONObject c=channels.optJSONObject((i+direction+channels.length())%channels.length()); runOnUiThread(()-> { if(g==generation&&!released) switchChannel(c); }); return; }
        } catch(Exception ignored) {} });
    }
    private void guide() {
        int g=generation; final String id=item.optString("Id");
        network.execute(()-> { try {
            JSONArray programs=Json.array(api.get("/LiveTv/Programs","UserId",api.account.user,"ChannelIds",id,"MinEndDate",java.time.Instant.now().toString(),"Limit",12,"SortBy","StartDate","SortOrder","Ascending","Fields","Overview"),"Items");
            String[] labels=new String[programs.length()];
            for(int i=0;i<programs.length();i++) { JSONObject p=programs.optJSONObject(i); String time=p.optString("StartDate"); try { time=java.time.Instant.parse(time).atZone(java.time.ZoneId.systemDefault()).toLocalTime().toString(); } catch(Exception ignored) {} labels[i]=time+"  "+p.optString("Name"); }
            runOnUiThread(()-> { if(g!=generation||released) return; new AlertDialog.Builder(this).setTitle("Programm · "+item.optString("Name")).setItems(labels,(d,w)->program(programs.optJSONObject(w))).setNegativeButton("Schließen",null).show(); });
        } catch(Exception e) { runOnUiThread(()->toast("Programm nicht verfügbar")); } });
    }
    private void program(JSONObject p) {
        new AlertDialog.Builder(this).setTitle(p.optString("Name")).setMessage(p.optString("Overview","Keine Beschreibung"))
            .setPositiveButton("Aufnehmen",(d,w)-> { network.execute(()-> { try { JSONObject timer=api.get("/LiveTv/Timers/Defaults","ProgramId",p.optString("Id")); timer.put("ProgramId",p.optString("Id")); api.post("/LiveTv/Timers",timer); runOnUiThread(()->toast("Aufnahme geplant")); } catch(Exception e) { runOnUiThread(()->toast("Aufnahme konnte nicht geplant werden")); } }); }).setNegativeButton("Schließen",null).show();
    }
    private void toast(String s) { if(!released) Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if(e.getAction()==KeyEvent.ACTION_DOWN) {
            if(live&&(e.getKeyCode()==KeyEvent.KEYCODE_CHANNEL_UP||e.getKeyCode()==KeyEvent.KEYCODE_CHANNEL_DOWN)) { zap(e.getKeyCode()==KeyEvent.KEYCODE_CHANNEL_UP?1:-1); return true; }
            if(e.getKeyCode()==KeyEvent.KEYCODE_MENU) { view.showController(); toolbar.setVisibility(View.VISIBLE); toolbar.getChildAt(1).requestFocus(); return true; }
            if(e.getKeyCode()==KeyEvent.KEYCODE_DPAD_UP&&!view.isControllerFullyVisible()) { view.showController(); toolbar.setVisibility(View.VISIBLE); if(skip.getVisibility()==View.VISIBLE) skip.requestFocus(); else toolbar.getChildAt(1).requestFocus(); return true; }
            if(e.getKeyCode()==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE&&player!=null) { if(player.isPlaying()) player.pause(); else player.play(); return true; }
        }
        return super.dispatchKeyEvent(e);
    }
    @Override public void onBackPressed() { if(view.isControllerFullyVisible()) { view.hideController(); toolbar.setVisibility(View.GONE); view.requestFocus(); } else finish(); }
    @Override protected void onSaveInstanceState(Bundle state) { state.putLong("position",position()); super.onSaveInstanceState(state); }
    @Override protected void onStop() { super.onStop(); release(); finish(); }
    private void release() {
        if(released) return; released=true; generation++; handler.removeCallbacksAndMessages(null); cleanupSession();
        if(player!=null) { view.setPlayer(null); player.release(); player=null; }
        api.http.dispatcher().cancelAll(); network.shutdownNow(); app.playing=false; getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        app.reports.execute(()->app.channels.refresh(null));
    }
    @Override protected void onDestroy() { release(); super.onDestroy(); }
}
