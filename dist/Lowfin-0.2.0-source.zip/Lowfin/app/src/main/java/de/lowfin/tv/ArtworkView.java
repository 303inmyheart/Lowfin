package de.lowfin.tv;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;

/** Width-driven image frame. FIT_CENTER preserves the entire supplied artwork. */
final class ArtworkView extends ImageView {
    private double ratio=2.0/3;
    ArtworkView(Context context) {
        super(context); setScaleType(ScaleType.FIT_CENTER); setBackground(Ui.background(0xff191919,0)); setClipToOutline(true);
    }
    void ratio(double value) { if(ratio!=value) { ratio=value; requestLayout(); } }
    @Override protected void onMeasure(int widthSpec,int heightSpec) {
        int width=View.MeasureSpec.getSize(widthSpec);
        int height=(int)Math.round(width/ratio);
        setMeasuredDimension(resolveSize(width,widthSpec),resolveSize(height,heightSpec));
    }
}
