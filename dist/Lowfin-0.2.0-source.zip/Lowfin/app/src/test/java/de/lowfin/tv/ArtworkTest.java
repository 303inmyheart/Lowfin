package de.lowfin.tv;

import org.junit.Test;
import org.json.*;
import static org.junit.Assert.*;

public class ArtworkTest {
    @Test public void postersAlwaysUseTwoByThreeAndEpisodesUseReportedRatio() {
        for(String kind:new String[]{"Movie","Series","Season","BoxSet"}) assertEquals(2.0/3,Artwork.ratio(Json.obj("Type",kind,"PrimaryImageAspectRatio",1.78),false),.0001);
        assertEquals(4.0/3,Artwork.ratio(Json.obj("Type","Episode","PrimaryImageAspectRatio",4.0/3),false),.0001);
    }
    @Test public void missingEpisodeThumbFallsBackToPortraitSeriesPoster() {
        JSONObject item=Json.obj("Id","episode","Type","Episode","SeriesId","series","SeriesPrimaryImageTag","poster");
        assertEquals(2.0/3,Artwork.ratio(item,true),.0001);
    }
    @Test public void landscapeArtworkIsChosenOnlyWhenItExists() {
        JSONObject movie=Json.obj("Id","movie","Type","Movie","ImageTags",Json.obj("Primary","poster","Thumb","thumb"));
        assertEquals("Thumb",Artwork.type(movie,true)); assertEquals("Primary",Artwork.type(movie,false));
        assertEquals(16.0/9,Artwork.ratio(movie,true),.0001);
        Api api=new Api(new Account("http://localhost/jellyfin","user","token","name","device"));
        assertTrue(api.image(movie,240,true).contains("/Images/Thumb?")); assertTrue(api.image(movie,240,false).contains("/Images/Primary?"));
    }
    @Test public void backdropsAndNullOrBadRatiosAreHandledSafely() {
        assertEquals("Backdrop",Artwork.type(Json.obj("Type","Movie","BackdropImageTags",Json.arr("backdrop")),true));
        assertEquals(16.0/9,Artwork.ratio(Json.obj("Type","Episode","PrimaryImageAspectRatio",0),false),.0001);
    }
}
