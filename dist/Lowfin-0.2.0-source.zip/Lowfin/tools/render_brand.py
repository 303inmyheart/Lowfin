"""Render the native Lowfin logo geometry as launcher and TV assets.

The editable sources are SVG. Pillow renders the same polygons and wordmark
at high resolution; no generated third-party artwork or system installation.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'design'
RES = ROOT / 'app/src/main/res'
ASSETS.mkdir(exist_ok=True)
MARK_L = [(260,250),(356,250),(356,658),(764,658),(764,754),(260,754)]
MARK_PLAY = [(424,262),(770,454),(424,646)]

def mark(draw, origin, scale):
    for points, color in [(MARK_L, '#f4f4f4'), (MARK_PLAY, '#dadada')]:
        draw.polygon([(origin[0]+x*scale, origin[1]+y*scale) for x,y in points], fill=color)

def background(width,height):
    image=Image.new('RGB',(width,height))
    d=ImageDraw.Draw(image)
    for y in range(height):
        g=round(25-10*y/max(1,height-1))
        d.line((0,y,width,y),fill=(g,g,g))
    return image

icon=background(2048,2048)
mark(ImageDraw.Draw(icon),(0,0),2)
for size in (1024,512):
    icon.resize((size,size),Image.Resampling.LANCZOS).save(ASSETS/f'lowfin-icon-{size}.png')
for density,size in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
    path=RES/f'mipmap-{density}'; path.mkdir(exist_ok=True)
    icon.resize((size,size),Image.Resampling.LANCZOS).save(path/'ic_launcher.png')

fg=Image.new('RGBA',(432,432),(0,0,0,0))
# The L + play mark fits the central safe circle of Android adaptive icons.
mark(ImageDraw.Draw(fg),(32,32),.36)
path=RES/'drawable-nodpi'; path.mkdir(exist_ok=True)
fg.save(path/'launcher_foreground.png')
fg.save(ASSETS/'lowfin-adaptive-foreground.png')

banner=background(2560,1440)
d=ImageDraw.Draw(banner)
# Quiet outlines retain the monochrome palette and leave the wordmark clear.
for radius in [680,840,1000]:
    d.ellipse((2560-radius,720-radius,2560+radius,720+radius),outline='#252525',width=2)
mark(d,(-12,210),1.05)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',216)
label='LOWFIN'; spacing=14
width=sum(d.textlength(ch,font=font) for ch in label)+spacing*(len(label)-1)
x=1160
for ch in label:
    d.text((x,584),ch,font=font,fill='#f4f4f4')
    x+=d.textlength(ch,font=font)+spacing
for w,h in [(1280,720),(320,180)]:
    banner.resize((w,h),Image.Resampling.LANCZOS).save(ASSETS/f'lowfin-google-tv-{w}x{h}.png')
path=RES/'drawable-xhdpi'; path.mkdir(exist_ok=True)
banner.resize((320,180),Image.Resampling.LANCZOS).save(path/'tv_banner.png')

paths='<path fill="#f4f4f4" d="M260 250H356V658H764V754H260Z"/><path fill="#dadada" d="M424 262L770 454L424 646Z"/>'
defs='<defs><linearGradient id="bg" x2="0" y2="1"><stop stop-color="#191919"/><stop offset="1" stop-color="#0f0f0f"/></linearGradient></defs>'
(ASSETS/'lowfin-icon.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1024 1024">{defs}<rect width="1024" height="1024" fill="url(#bg)"/>{paths}</svg>')
(ASSETS/'lowfin-google-tv.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="720" viewBox="0 0 2560 1440">{defs}<rect width="2560" height="1440" fill="url(#bg)"/><g fill="none" stroke="#252525" stroke-width="2"><circle cx="2560" cy="720" r="680"/><circle cx="2560" cy="720" r="840"/><circle cx="2560" cy="720" r="1000"/></g><g transform="translate(-12 210) scale(1.05)">{paths}</g><text x="1160" y="786" font-family="DejaVu Sans,sans-serif" font-size="216" letter-spacing="14" fill="#f4f4f4">LOWFIN</text></svg>')

preview=Image.new('RGB',(1440,580),'#080808')
preview.paste(icon.resize((500,500),Image.Resampling.LANCZOS),(40,40))
preview.paste(banner.resize((800,450),Image.Resampling.LANCZOS),(600,65))
preview.save(ASSETS/'lowfin-brand-preview.png')
print('Saved launcher icons, adaptive foreground, TV banners and editable SVGs to',ASSETS)
